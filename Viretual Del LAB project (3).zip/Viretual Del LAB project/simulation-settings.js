(function () {
    const storageKey = "virtualDeldLabSettings";
    const defaults = {
        simulationSpeed: "normal",
        connectionErrorDetection: true,
        truthTableVerification: true,
        autoRunSimulation: false,
        showOutputValues: true
    };
    const speedDelays = {
        slow: 1500,
        normal: 750,
        fast: 250
    };

    function normalizeSettings(candidate) {
        const source = candidate && typeof candidate === "object" ? candidate : {};
        return {
            simulationSpeed: Object.prototype.hasOwnProperty.call(speedDelays, source.simulationSpeed)
                ? source.simulationSpeed
                : defaults.simulationSpeed,
            connectionErrorDetection: typeof source.connectionErrorDetection === "boolean"
                ? source.connectionErrorDetection
                : defaults.connectionErrorDetection,
            truthTableVerification: typeof source.truthTableVerification === "boolean"
                ? source.truthTableVerification
                : defaults.truthTableVerification,
            autoRunSimulation: typeof source.autoRunSimulation === "boolean"
                ? source.autoRunSimulation
                : defaults.autoRunSimulation,
            showOutputValues: typeof source.showOutputValues === "boolean"
                ? source.showOutputValues
                : defaults.showOutputValues
        };
    }

    function getSettings() {
        try {
            const stored = window.localStorage.getItem(storageKey);
            return normalizeSettings(stored ? JSON.parse(stored) : defaults);
        } catch (error) {
            console.error("Unable to read saved Virtual DELD Lab settings.", error);
            return normalizeSettings(defaults);
        }
    }

    function saveSettings(nextSettings) {
        const settings = normalizeSettings(nextSettings);
        try {
            window.localStorage.setItem(storageKey, JSON.stringify(settings));
        } catch (error) {
            console.error("Unable to save Virtual DELD Lab settings.", error);
        }
        document.dispatchEvent(new CustomEvent("virtualdeldsettingschange", {
            detail: settings
        }));
        return settings;
    }

    function formatStatus(message) {
        const settings = getSettings();
        if (settings.showOutputValues) {
            return message;
        }
        return String(message).split("\n").filter(function (line) {
            return !/^\s*(Output|LED|SUM|CARRY|Previous Q|Current Q):/i.test(line);
        }).join("\n");
    }

    function setSetting(key, value) {
        const settings = getSettings();
        if (!Object.prototype.hasOwnProperty.call(defaults, key)) {
            throw new Error("Unknown Virtual DELD Lab setting: " + key);
        }
        settings[key] = value;
        return saveSettings(settings);
    }

    function applyPreferences(settings) {
        document.body.classList.toggle("settings-hide-output-values", !settings.showOutputValues);
        document.body.classList.toggle("settings-hide-truth-tables", !settings.truthTableVerification);

        document.querySelectorAll(
            "#outputValue, #ledState, #exp2SumValue, #exp2CarryValue, #exp3CurrentQ, #exp3PreviousQ, #exp3QBarValue"
        ).forEach(function (node) {
            const row = node.closest(".output-row");
            if (row) {
                row.dataset.outputValues = "true";
            }
        });

        const verifyButton = document.getElementById("exp3VerifyBtn");
        if (verifyButton) {
            verifyButton.disabled = !settings.truthTableVerification;
            verifyButton.title = settings.truthTableVerification
                ? "Compare the simulated output with the characteristic table."
                : "Enable Truth Table Verification in Settings to use this control.";
        }

        document.querySelectorAll("[data-setting]").forEach(function (button) {
            const enabled = settings[button.dataset.setting];
            button.classList.toggle("on", enabled);
            button.classList.toggle("off", !enabled);
            button.setAttribute("aria-checked", String(enabled));
        });

        document.querySelectorAll('input[name="simulationSpeed"]').forEach(function (radio) {
            radio.checked = radio.value === settings.simulationSpeed;
        });

        document.querySelectorAll(".status-box[data-full-status]").forEach(function (statusBox) {
            statusBox.textContent = formatStatus(statusBox.dataset.fullStatus);
        });
    }

    window.virtualDeldSettings = {
        defaults: Object.freeze(Object.assign({}, defaults)),
        get: getSettings,
        set: setSetting,
        formatStatus: formatStatus,
        getSimulationDelayMs: function () {
            return speedDelays[getSettings().simulationSpeed];
        }
    };

    document.addEventListener("DOMContentLoaded", function () {
        applyPreferences(getSettings());

        document.querySelectorAll('input[name="simulationSpeed"]').forEach(function (radio) {
            radio.addEventListener("change", function () {
                if (radio.checked) {
                    applyPreferences(setSetting("simulationSpeed", radio.value));
                }
            });
        });

        document.querySelectorAll("[data-setting]").forEach(function (button) {
            button.addEventListener("click", function () {
                const settings = getSettings();
                applyPreferences(setSetting(button.dataset.setting, !settings[button.dataset.setting]));
            });
        });

        document.addEventListener("virtualdeldsettingschange", function (event) {
            applyPreferences(event.detail);
        });
    });
})();
