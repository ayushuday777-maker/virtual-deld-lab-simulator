const gateLogic = {
    AND: function (a, b) {
        return (a && b) ? 1 : 0;
    },
    OR: function (a, b) {
        return (a || b) ? 1 : 0;
    },
    XOR: function (a, b) {
        return (a !== b) ? 1 : 0;
    },
    NOT: function (a) {
        return a ? 0 : 1;
    },
    NAND: function (a, b) {
        return gateLogic.AND(a, b) ? 0 : 1;
    },
    NOR: function (a, b) {
        return gateLogic.OR(a, b) ? 0 : 1;
    },
    XNOR: function (a, b) {
        return gateLogic.XOR(a, b) ? 0 : 1;
    }
};

function getVirtualLabSettings() {
    if (window.virtualDeldSettings) {
        return window.virtualDeldSettings.get();
    }
    return {
        simulationSpeed: "normal",
        connectionErrorDetection: true,
        truthTableVerification: true,
        autoRunSimulation: false,
        showOutputValues: true
    };
}

function setCircuitValidationError(statusHandler, validation) {
    const message = getVirtualLabSettings().connectionErrorDetection
        ? validation.message
        : "Circuit is incomplete or invalid. Complete the required connections before simulation.";
    statusHandler(message, true);
}

function scheduleCombinationalAutoRun(validateCircuit, runSimulation) {
    if (!getVirtualLabSettings().autoRunSimulation) {
        return;
    }

    window.clearTimeout(window.virtualDeldAutoRunTimer);
    window.virtualDeldAutoRunTimer = window.setTimeout(function () {
        if (getVirtualLabSettings().autoRunSimulation && validateCircuit().valid) {
            runSimulation();
        }
    }, 180);
}

function hasCircuitCycle(components, connections) {
    const outgoing = new Map();
    const visiting = new Set();
    const visited = new Set();

    connections.forEach(function (connection) {
        if (!outgoing.has(connection.from)) {
            outgoing.set(connection.from, []);
        }
        outgoing.get(connection.from).push(connection.to);
    });

    function visit(componentId) {
        if (visiting.has(componentId)) {
            return true;
        }
        if (visited.has(componentId)) {
            return false;
        }

        visiting.add(componentId);
        const targets = outgoing.get(componentId) || [];
        for (let index = 0; index < targets.length; index += 1) {
            if (visit(targets[index])) {
                return true;
            }
        }
        visiting.delete(componentId);
        visited.add(componentId);
        return false;
    }

    return components.some(function (component) {
        return visit(component.id);
    });
}

const gateMeta = {
    AND: { inputs: 2, rows: [[0, 0], [0, 1], [1, 0], [1, 1]], label: "AND" },
    OR: { inputs: 2, rows: [[0, 0], [0, 1], [1, 0], [1, 1]], label: "OR" },
    XOR: { inputs: 2, rows: [[0, 0], [0, 1], [1, 0], [1, 1]], label: "XOR" },
    NOT: { inputs: 1, rows: [[0], [1]], label: "NOT" },
    NAND: { inputs: 2, rows: [[0, 0], [0, 1], [1, 0], [1, 1]], label: "NAND" },
    NOR: { inputs: 2, rows: [[0, 0], [0, 1], [1, 0], [1, 1]], label: "NOR" },
    XNOR: { inputs: 2, rows: [[0, 0], [0, 1], [1, 0], [1, 1]], label: "XNOR" }
};

const exp1State = {
    selectedGate: "AND",
    components: [],
    connections: [],
    pendingConnection: null,
    truthResults: {
        AND: {},
        OR: {},
        NOT: {},
        NAND: {},
        NOR: {},
        XOR: {},
        XNOR: {}
    },
    completed: {
        AND: false,
        OR: false,
        NOT: false,
        NAND: false,
        NOR: false,
        XOR: false,
        XNOR: false
    }
};

const exp2State = {
    selectedCircuit: "halfAdder",
    components: [],
    connections: [],
    pendingConnection: null,
    truthResults: {
        halfAdder: {},
        fullAdder: {}
    },
    completed: {
        halfAdder: false,
        fullAdder: false
    }
};

const exp2TruthTables = {
    halfAdder: [
        { A: 0, B: 0, expectedSum: 0, expectedCarry: 0 },
        { A: 0, B: 1, expectedSum: 1, expectedCarry: 0 },
        { A: 1, B: 0, expectedSum: 1, expectedCarry: 0 },
        { A: 1, B: 1, expectedSum: 0, expectedCarry: 1 }
    ],
    fullAdder: [
        { A: 0, B: 0, Cin: 0, expectedSum: 0, expectedCarry: 0 },
        { A: 0, B: 0, Cin: 1, expectedSum: 1, expectedCarry: 0 },
        { A: 0, B: 1, Cin: 0, expectedSum: 1, expectedCarry: 0 },
        { A: 0, B: 1, Cin: 1, expectedSum: 0, expectedCarry: 1 },
        { A: 1, B: 0, Cin: 0, expectedSum: 1, expectedCarry: 0 },
        { A: 1, B: 0, Cin: 1, expectedSum: 0, expectedCarry: 1 },
        { A: 1, B: 1, Cin: 0, expectedSum: 0, expectedCarry: 1 },
        { A: 1, B: 1, Cin: 1, expectedSum: 1, expectedCarry: 1 }
    ]
};

const exp3State = {
    selectedFlipFlop: "SR",
    currentQ: null,
    previousQ: null,
    qBar: null,
    clockState: 0,
    previousClock: 0,
    components: [],
    connections: [],
    pendingConnection: null,
    inputValues: {
        S: 0,
        R: 0,
        J: 0,
        K: 0,
        D: 0,
        T: 0,
        CLK: 0
    },
    progress: {
        SR: 0,
        JK: 0,
        D: 0,
        T: 0
    },
    completed: {
        SR: false,
        JK: false,
        D: false,
        T: false
    },
    truthResults: {
        SR: [],
        JK: [],
        D: [],
        T: []
    },
    guidedProgress: {
        SR: { currentStep: 1, completedSteps: [] },
        JK: { currentStep: 1, completedSteps: [] },
        D: { currentStep: 1, completedSteps: [] },
        T: { currentStep: 1, completedSteps: [] }
    },
    lastOperation: "No transition yet.",
    lastSimulationResult: null,
    lastSimulationLabel: null,
    lastSimulationInputs: null,
    lastSimulationPreviousQ: null,
    initialized: false
};

const exp3Definitions = {
    SR: {
        label: "SR",
        inputs: ["S", "R", "CLK"],
        required: ["S", "R", "CLK", "FF", "Q", "QBar"],
        rows: [
            { label: "S=0, R=0", S: 0, R: 0, expected: "Q(previous)", operation: "Hold" },
            { label: "S=0, R=1", S: 0, R: 1, expected: 0, operation: "Reset" },
            { label: "S=1, R=0", S: 1, R: 0, expected: 1, operation: "Set" },
            { label: "S=1, R=1", S: 1, R: 1, expected: "Invalid", operation: "Forbidden" }
        ]
    },
    JK: {
        label: "JK",
        inputs: ["J", "K", "CLK"],
        required: ["J", "K", "CLK", "FF", "Q", "QBar"],
        rows: [
            { label: "J=0, K=0", J: 0, K: 0, expected: "Q(previous)", operation: "Hold" },
            { label: "J=0, K=1", J: 0, K: 1, expected: 0, operation: "Reset" },
            { label: "J=1, K=0", J: 1, K: 0, expected: 1, operation: "Set" },
            { label: "J=1, K=1", J: 1, K: 1, expected: "NOT Q(previous)", operation: "Toggle" }
        ]
    },
    D: {
        label: "D",
        inputs: ["D", "CLK"],
        required: ["D", "CLK", "FF", "Q", "QBar"],
        rows: [
            { label: "D=0", D: 0, expected: 0, operation: "Reset to 0" },
            { label: "D=1", D: 1, expected: 1, operation: "Set to 1" }
        ]
    },
    T: {
        label: "T",
        inputs: ["T", "CLK"],
        required: ["T", "CLK", "FF", "Q", "QBar"],
        rows: [
            { label: "T=0", T: 0, expected: "Q(previous)", operation: "Hold" },
            { label: "T=1", T: 1, expected: "NOT Q(previous)", operation: "Toggle" }
        ]
    }
};

const exp3GuidedSteps = {
    SR: [
        {
            title: "Understand the SR Flip-Flop",
            instruction: "The SR flip-flop has two control inputs: S (Set) and R (Reset). Its outputs are Q and Q̅. Initialize the circuit before testing the inputs.",
            action: "Review the input and output terminals.",
            controls: ["S", "R", "Q", "QBar"],
            connectionRequirement: "This implementation is an edge-triggered SR flip-flop block. S, R, and CLK are required inputs; S = R = 1 is invalid.",
            stepType: "review"
        },
        {
            title: "Build the Circuit",
            instruction: "Place the edge-triggered SR flip-flop block on the canvas. Connect S, R, and CLK to their matching inputs, then connect Q and Q̅ to their indicators.",
            action: "Place components and connect the circuit.",
            controls: ["S", "R", "CLK", "FF", "Q", "QBar"],
            connectionRequirement: "Connect S, R, and CLK to the flip-flop, and connect its Q and Q̅ outputs to their matching indicators.",
            stepType: "build"
        },
        {
            title: "Initialize the State",
            instruction: "Click Reset/Initialize to establish the documented initial state. Check the displayed values of Q and Q̅ before continuing.",
            action: "Initialize the circuit and observe the state.",
            controls: ["Reset / Initialize"],
            connectionRequirement: "Use the reset action before testing any valid SR transition.",
            stepType: "initialize"
        },
        {
            title: "Test Hold",
            instruction: "Set S = 0 and R = 0. Perform the required latch or clock operation. Observe whether Q retains its previous valid state.",
            action: "Set inputs, perform the required operation, and run the simulation.",
            controls: ["S", "R", "CLK"],
            connectionRequirement: "Use the actual SR input combination before the active clock or latch action.",
            stepType: "input"
        },
        {
            title: "Test Reset",
            instruction: "Set S = 0 and R = 1. Perform the required operation. Observe whether Q becomes 0 and Q̅ becomes 1.",
            action: "Run the simulation and record the observed outputs.",
            controls: ["S", "R", "CLK"],
            connectionRequirement: "Record the reset state using the actual circuit output after the clock or enable action.",
            stepType: "input"
        },
        {
            title: "Test Set",
            instruction: "Set S = 1 and R = 0. Perform the required operation. Observe whether Q becomes 1 and Q̅ becomes 0.",
            action: "Run the simulation and record the observed outputs.",
            controls: ["S", "R", "CLK"],
            connectionRequirement: "Use the set condition and compare the measured Q and Q̅ values.",
            stepType: "input"
        },
        {
            title: "Investigate the Invalid Input",
            instruction: "Set S = 1 and R = 1. Run the simulation and observe the warning for the forbidden input combination in the active-high NOR-based SR implementation.",
            action: "Observe the warning and understand why this input combination is invalid. Do not record it as a successful valid state transition.",
            controls: ["S", "R", "CLK"],
            connectionRequirement: "This forbidden case must be evaluated as an invalid state, not as a valid output.",
            stepType: "input"
        },
        {
            title: "Verify Results",
            instruction: "Compare the outputs you actually obtained with the SR characteristic table. Verify each valid test case individually.",
            action: "Verify the performed cases and review any errors.",
            controls: ["Verify Result", "Characteristic Table"],
            connectionRequirement: "Only verify after a real simulation result is available for the selected SR condition.",
            stepType: "verify"
        }
    ],
    JK: [
        {
            title: "Understand the JK Flip-Flop",
            instruction: "The JK flip-flop has inputs J and K, a clock input, and outputs Q and Q̅. Unlike the SR implementation, J = 1 and K = 1 produces a toggle operation.",
            action: "Review the JK inputs and the active clock edge behavior.",
            controls: ["J", "K", "CLK", "Q", "QBar"],
            connectionRequirement: "Confirm the data and clock inputs are connected before simulating.",
            stepType: "review"
        },
        {
            title: "Build the Circuit",
            instruction: "Place the JK flip-flop on the canvas. Connect J, K, the clock input, Q, and Q̅ using the available terminals.",
            action: "Place the JK flip-flop and connect all required terminals.",
            controls: ["J", "K", "CLK", "FF", "Q", "QBar"],
            connectionRequirement: "The JK block and output indicators must be included in the circuit.",
            stepType: "build"
        },
        {
            title: "Initialize the State",
            instruction: "Initialize the circuit to a known state. Confirm the current values of Q and Q̅.",
            action: "Initialize the circuit and observe the starting state.",
            controls: ["Reset / Initialize"],
            connectionRequirement: "A defined starting state is required before testing the JK input combinations.",
            stepType: "initialize"
        },
        {
            title: "Test Hold",
            instruction: "Set J = 0 and K = 0. Apply an active clock edge. Observe whether Q remains unchanged.",
            action: "Set J and K, apply the pulse, and observe the state.",
            controls: ["J", "K", "CLK"],
            connectionRequirement: "The active edge must be applied after the inputs are set.",
            stepType: "input"
        },
        {
            title: "Test Reset",
            instruction: "Set J = 0 and K = 1. Apply an active clock edge. Observe whether Q becomes 0.",
            action: "Run the simulation and record the observed outputs.",
            controls: ["J", "K", "CLK"],
            connectionRequirement: "The reset operation should be evaluated at the active clock edge.",
            stepType: "input"
        },
        {
            title: "Test Set",
            instruction: "Set J = 1 and K = 0. Apply an active clock edge. Observe whether Q becomes 1.",
            action: "Run the simulation and record the observed outputs.",
            controls: ["J", "K", "CLK"],
            connectionRequirement: "The set operation should be evaluated at the active clock edge.",
            stepType: "input"
        },
        {
            title: "Test Toggle",
            instruction: "Set J = 1 and K = 1. Apply one active clock edge. Record Q. Apply another active clock edge without changing J or K and observe whether Q toggles again.",
            action: "Use the actual previous state and perform two active clock edges.",
            controls: ["J", "K", "CLK", "Q"],
            connectionRequirement: "The toggle must be evaluated using the previous Q value, not only the current inputs.",
            stepType: "input"
        },
        {
            title: "Verify Results",
            instruction: "Compare your observed state transitions with the JK characteristic table. Verify all four input combinations, including the repeated toggle operation.",
            action: "Verify the performed cases and confirm the actual state transitions.",
            controls: ["Verify Result", "Characteristic Table"],
            connectionRequirement: "Verification is only valid after a real simulation result exists for the tested JK inputs.",
            stepType: "verify"
        }
    ],
    D: [
        {
            title: "Understand the D Flip-Flop",
            instruction: "The D flip-flop has one data input D, a clock input, and outputs Q and Q̅. The value of D is sampled at the active clock edge.",
            action: "Review the D input and the active-edge sampling behavior.",
            controls: ["D", "CLK", "Q", "QBar"],
            connectionRequirement: "Confirm D and CLK are connected to the edge-triggered flip-flop.",
            stepType: "review"
        },
        {
            title: "Build the Circuit",
            instruction: "Place the D flip-flop on the canvas. Connect D, CLK, Q, and Q̅ to their appropriate terminals.",
            action: "Place the D flip-flop and connect the terminals.",
            controls: ["D", "CLK", "FF", "Q", "QBar"],
            connectionRequirement: "The D input, clock input, and output terminals must be included in the circuit.",
            stepType: "build"
        },
        {
            title: "Initialize the State",
            instruction: "Initialize the circuit and observe the current Q state.",
            action: "Reset the circuit and check the starting state.",
            controls: ["Reset / Initialize"],
            connectionRequirement: "The state should be initialized before checking D sampling.",
            stepType: "initialize"
        },
        {
            title: "Test D = 0",
            instruction: "Set D = 0. Before applying a clock pulse, observe whether Q retains its previous state. Then apply the active clock edge and record the resulting Q value.",
            action: "Set D, apply the clock edge, and record the observed output.",
            controls: ["D", "CLK"],
            connectionRequirement: "The output should update only after the active edge, not immediately when D changes.",
            stepType: "input"
        },
        {
            title: "Test D = 1",
            instruction: "Set D = 1. Observe Q before the active clock edge. Apply the active clock edge and check whether Q becomes 1.",
            action: "Set D to 1, apply the clock pulse, and note the observed Q value.",
            controls: ["D", "CLK"],
            connectionRequirement: "The output should reflect the sampled D value only after the active edge.",
            stepType: "input"
        },
        {
            title: "Verify Sampling Behavior",
            instruction: "Change D after the clock edge without applying another active edge. Confirm that Q does not immediately follow D in the edge-triggered implementation.",
            action: "Test the no-immediate-update behavior after the edge.",
            controls: ["D", "CLK", "Q"],
            connectionRequirement: "Do not change Q until the next active clock edge occurs.",
            stepType: "input"
        },
        {
            title: "Verify Results",
            instruction: "Compare the sampled values with the D flip-flop characteristic table and verify the observed transitions.",
            action: "Use actual simulation results to confirm the D-flip-flop behavior.",
            controls: ["Verify Result", "Characteristic Table"],
            connectionRequirement: "Verification is valid only after a real D-sampled simulation result is recorded.",
            stepType: "verify"
        }
    ],
    T: [
        {
            title: "Understand the T Flip-Flop",
            instruction: "The T flip-flop has one input T, a clock input, and outputs Q and Q̅. T = 0 holds the current state, while T = 1 toggles the state at the active clock edge.",
            action: "Review the T input and clock-triggered toggle behavior.",
            controls: ["T", "CLK", "Q", "QBar"],
            connectionRequirement: "Confirm the T input and clock are connected to the active-edge T flip-flop.",
            stepType: "review"
        },
        {
            title: "Build the Circuit",
            instruction: "Place the T flip-flop on the canvas. Connect T, CLK, Q, and Q̅ to the appropriate terminals.",
            action: "Place the T flip-flop and connect the required terminals.",
            controls: ["T", "CLK", "FF", "Q", "QBar"],
            connectionRequirement: "The T signal, clock signal, and outputs must be connected to the flip-flop block.",
            stepType: "build"
        },
        {
            title: "Initialize the State",
            instruction: "Initialize the circuit and observe the starting value of Q.",
            action: "Reset the circuit and inspect the initial state.",
            controls: ["Reset / Initialize"],
            connectionRequirement: "The starting state must be known before checking hold and toggle behavior.",
            stepType: "initialize"
        },
        {
            title: "Test Hold",
            instruction: "Set T = 0. Apply an active clock edge and observe whether Q remains unchanged.",
            action: "Set T to 0, apply the clock pulse, and confirm the hold behavior.",
            controls: ["T", "CLK"],
            connectionRequirement: "The clock edge should not toggle the state when T = 0.",
            stepType: "input"
        },
        {
            title: "Test Toggle",
            instruction: "Set T = 1. Apply one active clock edge and record Q. Apply a second active clock edge while T remains 1 and observe the next state.",
            action: "Apply repeated active-edged pulses while T remains at 1.",
            controls: ["T", "CLK", "Q"],
            connectionRequirement: "The state should alternate after each active edge while T = 1.",
            stepType: "input"
        },
        {
            title: "Repeat the Toggle Test",
            instruction: "Continue applying clock pulses while T = 1. Confirm that Q alternates between 0 and 1 after each active edge.",
            action: "Repeat the toggle operation and observe the recurring pattern.",
            controls: ["T", "CLK", "Q"],
            connectionRequirement: "The toggle state must be observed using repeated edge-triggered operations.",
            stepType: "input"
        },
        {
            title: "Verify Results",
            instruction: "Compare your observed transitions with the T flip-flop characteristic table. Verify both hold and toggle behavior.",
            action: "Verify both the hold and toggle results using real recorded output values.",
            controls: ["Verify Result", "Characteristic Table"],
            connectionRequirement: "Verification should only be performed after real simulation results are available.",
            stepType: "verify"
        }
    ]
};

function exp3NormalizeSignal(value) {
    if (value === true || value === "1" || value === 1) {
        return 1;
    }
    if (value === false || value === "0" || value === 0 || value === null) {
        return value === null ? null : 0;
    }
    return Number(value) === 1 ? 1 : 0;
}

function exp3GetSelectedDefinition() {
    return exp3Definitions[exp3State.selectedFlipFlop];
}

function exp3GetRequiredFFPorts() {
    const selected = exp3State.selectedFlipFlop;
    if (selected === "SR") {
        return ["S", "R", "CLK"];
    }
    if (selected === "JK") {
        return ["J", "K", "CLK"];
    }
    if (selected === "D") {
        return ["D", "CLK"];
    }
    return ["T", "CLK"];
}

function exp3GetComponentPins(type) {
    const selectedPorts = exp3GetRequiredFFPorts();
    if (type === "FF") {
        const pins = [];
        const portGroups = {
            SR: ["S", "R", "CLK"],
            JK: ["J", "K", "CLK"],
            D: ["D", "CLK"],
            T: ["T", "CLK"]
        };
        const activePorts = portGroups[exp3State.selectedFlipFlop] || ["S", "R", "CLK"];
        activePorts.forEach(function (port) {
            pins.push({ port: port, label: port });
        });
        pins.push({ port: "Q", label: "Q" }, { port: "QBar", label: "Q̅" });
        return pins;
    }
    if (type === "Q" || type === "QBar") {
        return [{ port: "input", label: "in" }];
    }
    if (type === "CLK") {
        return [{ port: "output", label: "out" }];
    }
    if (type === "S" || type === "R" || type === "J" || type === "K" || type === "D" || type === "T") {
        return [{ port: "output", label: "out" }];
    }
    return [{ port: "output", label: "out" }];
}

function exp3GetPinCoordinates(component, port) {
    const width = 110;
    const height = 52;
    const x = component.x;
    const y = component.y;

    if (component.type === "FF") {
        const portMap = {
            S: { x: x + 6, y: y + 18 },
            R: { x: x + 6, y: y + 30 },
            J: { x: x + 6, y: y + 18 },
            K: { x: x + 6, y: y + 30 },
            D: { x: x + 6, y: y + 22 },
            T: { x: x + 6, y: y + 22 },
            CLK: { x: x + 6, y: y + 42 },
            Q: { x: x + width - 6, y: y + height / 2 - 9 },
            QBar: { x: x + width - 6, y: y + height / 2 + 12 }
        };
        return portMap[port] || { x: x + width - 6, y: y + height / 2 };
    }

    if (component.type === "Q" || component.type === "QBar") {
        return { x: x + 6, y: y + height / 2 };
    }

    if (port === "input") {
        return { x: x + 6, y: y + height / 2 };
    }

    return { x: x + width - 6, y: y + height / 2 };
}

function exp3ValidateConnection(fromComponent, fromPort, toComponent, toPort) {
    const sourceAllowed = fromComponent.type === "S" || fromComponent.type === "R" || fromComponent.type === "J" || fromComponent.type === "K" || fromComponent.type === "D" || fromComponent.type === "T" || fromComponent.type === "CLK" || (fromComponent.type === "FF" && (fromPort === "Q" || fromPort === "QBar"));
    if (!sourceAllowed) {
        return { valid: false, message: "Invalid connection. Source handles must be output terminals." };
    }

    if (fromComponent.id === toComponent.id) {
        return { valid: false, message: "A component cannot connect to itself." };
    }

    if (toComponent.type === "FF") {
        const validPorts = exp3GetRequiredFFPorts();
        if (!validPorts.includes(toPort)) {
            return { valid: false, message: "This flip-flop input is not valid for the selected model." };
        }
        return { valid: true, message: "Connection successful." };
    }

    if (toComponent.type === "Q" || toComponent.type === "QBar") {
        if (toPort !== "input") {
            return { valid: false, message: "Output indicators accept only valid input connections." };
        }
        if (fromComponent.type === "Q" || fromComponent.type === "QBar") {
            return { valid: false, message: "An output indicator cannot drive another output indicator." };
        }
        return { valid: true, message: "Connection successful." };
    }

    if (toComponent.type === "S" || toComponent.type === "R" || toComponent.type === "J" || toComponent.type === "K" || toComponent.type === "D" || toComponent.type === "T" || toComponent.type === "CLK") {
        return { valid: false, message: "Input sources cannot receive a connection." };
    }

    return { valid: false, message: "This connection is not allowed in the current flip-flop circuit." };
}

function exp3HandlePinClick(componentId, port) {
    const component = exp3State.components.find(function (item) {
        return item.id === componentId;
    });

    if (!component) {
        return;
    }

    if (!exp3State.pendingConnection) {
        exp3State.pendingConnection = { from: componentId, fromPort: port };
        exp3SetStatus("Select a destination input to complete the connection.", false);
        return;
    }

    if (exp3State.pendingConnection.from === componentId) {
        exp3State.pendingConnection = null;
        setCircuitValidationError(exp3SetStatus, { message: "Invalid connection. A component cannot connect to itself." });
        return;
    }

    const fromComponent = exp3State.components.find(function (item) {
        return item.id === exp3State.pendingConnection.from;
    });

    if (!fromComponent) {
        exp3State.pendingConnection = null;
        return;
    }

    const result = exp3ValidateConnection(fromComponent, exp3State.pendingConnection.fromPort, component, port);
    if (!result.valid) {
        exp3State.pendingConnection = null;
        setCircuitValidationError(exp3SetStatus, result);
        return;
    }

    const alreadyExists = exp3State.connections.some(function (connection) {
        return connection.from === fromComponent.id && connection.fromPort === exp3State.pendingConnection.fromPort && connection.to === component.id && connection.toPort === port;
    });

    if (!alreadyExists) {
        exp3State.connections.push({
            from: fromComponent.id,
            fromPort: exp3State.pendingConnection.fromPort,
            to: component.id,
            toPort: port
        });
    }

    exp3State.pendingConnection = null;
    exp3RenderCanvas();
    exp3SetStatus("Connection successful.", false);
}

function exp3ToggleInputValue(type) {
    if (!type || !Object.prototype.hasOwnProperty.call(exp3State.inputValues, type)) {
        return;
    }

    const current = Number(exp3State.inputValues[type]) || 0;
    const nextValue = current === 1 ? 0 : 1;
    exp3State.inputValues[type] = nextValue;

    if (type === "CLK") {
        exp3State.clockState = nextValue;
    }

    exp3RenderCanvas();
    exp3UpdateSimulationPanel();
    exp3RenderTruthTable();
    exp3SetStatus("Input " + type + " set to " + nextValue + ".", false);
}

function exp3MoveComponent(componentId, dx, dy) {
    const component = exp3State.components.find(function (item) {
        return item.id === componentId;
    });

    if (!component) {
        return;
    }

    component.x = Math.max(10, Math.min(650, component.x + dx));
    component.y = Math.max(10, Math.min(430, component.y + dy));
    exp3RenderCanvas();
    exp3UpdateSimulationPanel();
}

function exp3GetGuidedProgress(type) {
    const selectedType = type || exp3State.selectedFlipFlop;
    if (!exp3State.guidedProgress[selectedType]) {
        exp3State.guidedProgress[selectedType] = { currentStep: 1, completedSteps: [] };
    }
    return exp3State.guidedProgress[selectedType];
}

function exp3ResetGuidedProgress() {
    Object.keys(exp3GuidedSteps).forEach(function (type) {
        exp3State.guidedProgress[type] = {
            currentStep: 1,
            completedSteps: []
        };
    });
}

function exp3ResetSequentialState() {
    exp3State.pendingConnection = null;
    exp3State.currentQ = 0;
    exp3State.previousQ = null;
    exp3State.qBar = 1;
    exp3State.clockState = 0;
    exp3State.previousClock = 0;
    exp3State.lastOperation = "State initialized.";
    exp3State.lastSimulationResult = null;
    exp3State.lastSimulationLabel = null;
    exp3State.lastSimulationInputs = null;
    exp3State.lastSimulationPreviousQ = null;
    exp3State.initialized = true;
    exp3State.inputValues = { S: 0, R: 0, J: 0, K: 0, D: 0, T: 0, CLK: 0 };
    exp3ResetGuidedProgress();
    Object.keys(exp3State.truthResults).forEach(function (key) {
        exp3State.truthResults[key] = [];
    });
    Object.keys(exp3State.progress).forEach(function (key) {
        exp3State.progress[key] = 0;
    });
    Object.keys(exp3State.completed).forEach(function (key) {
        exp3State.completed[key] = false;
    });
    exp3RenderCanvas();
    exp3RenderTruthTable();
    exp3UpdateSimulationPanel();
    exp3RenderProgress();
    exp3RenderGuidedMode();
    exp3SetStatus("State initialized to Q = 0. The current circuit and connections were preserved.", false);
}

function exp3ClearCircuit() {
    exp3State.components = [];
    exp3State.connections = [];
    exp3State.pendingConnection = null;
    exp3State.currentQ = null;
    exp3State.previousQ = null;
    exp3State.qBar = null;
    exp3State.clockState = 0;
    exp3State.previousClock = 0;
    exp3State.lastOperation = "Circuit cleared.";
    exp3State.lastSimulationResult = null;
    exp3State.lastSimulationLabel = null;
    exp3State.lastSimulationInputs = null;
    exp3State.lastSimulationPreviousQ = null;
    exp3State.initialized = false;
    exp3State.inputValues = { S: 0, R: 0, J: 0, K: 0, D: 0, T: 0, CLK: 0 };
    exp3ResetGuidedProgress();
    Object.keys(exp3State.truthResults).forEach(function (key) {
        exp3State.truthResults[key] = [];
    });
    Object.keys(exp3State.progress).forEach(function (key) {
        exp3State.progress[key] = 0;
    });
    Object.keys(exp3State.completed).forEach(function (key) {
        exp3State.completed[key] = false;
    });
    exp3RenderCanvas();
    exp3RenderTruthTable();
    exp3UpdateSimulationPanel();
    exp3RenderProgress();
    exp3RenderGuidedMode();
    exp3SetStatus("Circuit cleared. Build a new flip-flop circuit and initialize its state.", false);
}

function exp3AddComponent(type) {
    if (!type) {
        return;
    }

    const component = {
        id: "exp3-comp-" + Date.now() + Math.random().toString(16).slice(2),
        type: type,
        label: type === "Q" ? "Q" : type === "QBar" ? "Q̅" : type,
        x: 80 + (exp3State.components.length % 4) * 80,
        y: 80 + (exp3State.components.length % 3) * 90,
        value: 0
    };

    exp3State.components.push(component);
    exp3RenderCanvas();
    exp3UpdateSimulationPanel();
    exp3RenderTruthTable();
    exp3SetStatus("Component added: " + component.label + ". Connect it and configure the inputs.", false);
}

function exp3GetComponentDefinitions() {
    return exp3State.components;
}

function exp3GetStepCompletionStatus(type, stepIndex) {
    const step = exp3GuidedSteps[type][stepIndex];
    if (!step) {
        return { complete: false, message: "Step not available." };
    }

    if (step.stepType === "review") {
        return { complete: true, message: "Review complete." };
    }

    if (step.stepType === "build") {
        const validation = exp3ValidateCircuit();
        return {
            complete: validation.valid,
            message: validation.valid
                ? "All required components and connections are present."
                : validation.message
        };
    }

    if (step.stepType === "initialize") {
        return { complete: exp3State.initialized, message: exp3State.initialized ? "Circuit initialized." : "Initialize the state before continuing." };
    }

    if (step.stepType === "verify") {
        const matches = exp3State.truthResults[type] && exp3State.truthResults[type].length > 0;
        return { complete: matches, message: matches ? "One or more results have been verified." : "Run a real simulation and verify the result before moving on." };
    }

    const inputValues = exp3State.inputValues;
    const values = step.controls.filter(function (control) {
        return control !== "Q" && control !== "QBar" && control !== "CLK" && control !== "Verify Result" && control !== "Characteristic Table";
    });

    const requiredState = values.length > 0;
    const hasInputValues = values.every(function (control) {
        if (control === "S") {
            return inputValues.S === 0 || inputValues.S === 1;
        }
        if (control === "R") {
            return inputValues.R === 0 || inputValues.R === 1;
        }
        if (control === "J") {
            return inputValues.J === 0 || inputValues.J === 1;
        }
        if (control === "K") {
            return inputValues.K === 0 || inputValues.K === 1;
        }
        if (control === "D") {
            return inputValues.D === 0 || inputValues.D === 1;
        }
        if (control === "T") {
            return inputValues.T === 0 || inputValues.T === 1;
        }
        if (control === "CLK") {
            return inputValues.CLK === 0 || inputValues.CLK === 1;
        }
        return true;
    });

    const hasSimulation = Boolean(exp3State.lastSimulationResult) &&
        JSON.stringify(exp3GetCurrentInputValues()) === JSON.stringify(exp3State.lastSimulationInputs) &&
        exp3State.previousQ === exp3State.lastSimulationPreviousQ;
    const status = requiredState && hasInputValues && hasSimulation;
    return {
        complete: status,
        message: status ? "Required input and simulation data are present." : "Set the required inputs and run the simulation to complete this step."
    };
}

function exp3RenderGuidedMode() {
    const container = document.getElementById("exp3GuidedText");
    if (!container) {
        return;
    }

    const type = exp3State.selectedFlipFlop;
    const steps = exp3GuidedSteps[type] || exp3GuidedSteps.SR;
    const progress = exp3GetGuidedProgress(type);
    const safeStepIndex = Math.min(Math.max(progress.currentStep - 1, 0), Math.max(steps.length - 1, 0));
    progress.currentStep = safeStepIndex + 1;
    const stepIndex = safeStepIndex;
    const currentStep = steps[stepIndex] || steps[0];
    const completion = exp3GetStepCompletionStatus(type, stepIndex);

    const progressWidth = steps.length > 0 ? ((stepIndex + 1) / steps.length) * 100 : 0;
    const progressLabel = type + " Flip-Flop: Step " + (stepIndex + 1) + " of " + steps.length;

    container.innerHTML = [
        '<div class="guided-header" style="display:flex;justify-content:space-between;align-items:center;gap:12px;margin-bottom:10px;">',
        '  <strong>' + progressLabel + '</strong>',
        '  <span class="guided-step-badge" style="font-size:12px;color:#23442f;">' + (completion.complete ? 'Step complete' : 'In progress') + '</span>',
        '</div>',
        '<div class="guided-progress" style="height:8px;background:#dfe9e0;border-radius:999px;overflow:hidden;margin-bottom:12px;">',
        '  <div style="width:' + progressWidth + '%;height:100%;background:#5e8f63;border-radius:999px;"></div>',
        '</div>',
        '<div class="guided-step-number" style="font-size:12px;font-weight:700;color:#4c6f57;letter-spacing:0.05em;margin-bottom:6px;">STEP ' + (stepIndex + 1) + '</div>',
        '<div class="guided-step-title" style="font-size:16px;font-weight:700;color:#23442f;margin-bottom:8px;">' + currentStep.title + '</div>',
        '<div class="guided-step-instruction" style="margin-bottom:8px;line-height:1.6;">' + currentStep.instruction + '</div>',
        '<div class="guided-step-action" style="margin-bottom:8px;padding:8px 10px;background:#f4faf4;border:1px solid #dfe8df;border-radius:8px;"><strong>Required student action:</strong> ' + currentStep.action + '</div>',
        '<div class="guided-step-meta" style="margin-bottom:12px;line-height:1.5;">',
        '  <div><strong>Required controls:</strong> ' + currentStep.controls.join(', ') + '</div>',
        '  <div><strong>Connection requirement:</strong> ' + currentStep.connectionRequirement + '</div>',
        '</div>',
        '<div class="guided-step-status" style="padding:8px 10px;border-radius:8px;background:#edf6ee;border:1px solid #dfe8df;color:#23442f;margin-bottom:12px;">' + completion.message + '</div>',
        '<div class="guided-step-nav" style="display:flex;justify-content:space-between;gap:10px;">',
        '  <button class="secondary-button" type="button" data-guide-nav="prev" ' + (stepIndex === 0 ? 'disabled' : '') + '>Previous Step</button>',
        '  <button class="primary-button" type="button" data-guide-nav="next" ' + (stepIndex >= steps.length - 1 ? 'disabled' : '') + '>Next Step</button>',
        '</div>'
    ].join("");

    const previousButton = container.querySelector('[data-guide-nav="prev"]');
    const nextButton = container.querySelector('[data-guide-nav="next"]');

    if (previousButton) {
        previousButton.addEventListener("click", function () {
            if (progress.currentStep > 1) {
                progress.currentStep -= 1;
                exp3RenderGuidedMode();
            }
        });
    }

    if (nextButton) {
        nextButton.addEventListener("click", function () {
            if (progress.currentStep < steps.length) {
                progress.currentStep += 1;
                exp3RenderGuidedMode();
            }
        });
    }
}

function exp3RenderCanvas() {
    const canvas = document.getElementById("exp3CircuitCanvas");
    if (!canvas) {
        return;
    }

    canvas.innerHTML = "";

    const svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
    svg.setAttribute("viewBox", "0 0 800 520");
    svg.setAttribute("width", "100%");
    svg.setAttribute("height", "100%");
    svg.style.position = "absolute";
    svg.style.inset = "0";
    svg.style.pointerEvents = "none";
    svg.style.zIndex = "1";
    canvas.appendChild(svg);

    if (exp3State.components.length === 0) {
        const emptyNotice = document.createElement("div");
        emptyNotice.className = "guided-box";
        emptyNotice.textContent = "No circuit found. Place the required components and connect them before running the simulation.";
        emptyNotice.style.position = "absolute";
        emptyNotice.style.left = "18px";
        emptyNotice.style.right = "18px";
        emptyNotice.style.top = "18px";
        emptyNotice.style.zIndex = "2";
        canvas.appendChild(emptyNotice);
        return;
    }

    exp3State.connections.forEach(function (connection) {
        const fromComponent = exp3State.components.find(function (item) {
            return item.id === connection.from;
        });
        const toComponent = exp3State.components.find(function (item) {
            return item.id === connection.to;
        });

        if (!fromComponent || !toComponent) {
            return;
        }

        const fromPoint = exp3GetPinCoordinates(fromComponent, connection.fromPort);
        const toPoint = exp3GetPinCoordinates(toComponent, connection.toPort);

        const line = document.createElementNS("http://www.w3.org/2000/svg", "path");
        line.setAttribute("d", "M " + fromPoint.x + " " + fromPoint.y + " C " + (fromPoint.x + 60) + " " + fromPoint.y + ", " + (toPoint.x - 60) + " " + toPoint.y + ", " + toPoint.x + " " + toPoint.y);
        line.setAttribute("fill", "none");
        line.setAttribute("stroke", "#4d7d58");
        line.setAttribute("stroke-width", "3");
        line.style.pointerEvents = "none";
        svg.appendChild(line);
    });

    exp3State.components.forEach(function (component) {
        const item = document.createElement("div");
        item.className = "circuit-component " + component.type;
        item.style.left = component.x + "px";
        item.style.top = component.y + "px";
        item.setAttribute("data-id", component.id);
        item.setAttribute("title", component.label);

        const label = document.createElement("div");
        label.className = "component-label";
        label.textContent = component.label;
        item.appendChild(label);

        const valueNode = document.createElement("div");
        valueNode.className = component.type === "Q" || component.type === "QBar"
            ? "component-value output-value"
            : "component-value";
        valueNode.textContent = component.type === "QBar" ? String(exp3State.qBar === null ? "Unknown" : exp3State.qBar) : component.type === "Q" ? String(exp3State.currentQ === null ? "Unknown" : exp3State.currentQ) : String(exp3State.inputValues[component.type] !== undefined ? exp3State.inputValues[component.type] : component.value);
        valueNode.addEventListener("click", function (event) {
            event.stopPropagation();
            if (Object.prototype.hasOwnProperty.call(exp3State.inputValues, component.type)) {
                exp3ToggleInputValue(component.type);
            }
        });
        item.appendChild(valueNode);

        const pins = exp3GetComponentPins(component.type);
        pins.forEach(function (pinInfo) {
            const pin = document.createElement("button");
            pin.type = "button";
            pin.className = "pin " + pinInfo.port;
            pin.dataset.componentId = component.id;
            pin.dataset.port = pinInfo.port;
            pin.textContent = pinInfo.label;
            pin.addEventListener("click", function (event) {
                event.stopPropagation();
                exp3HandlePinClick(component.id, pinInfo.port);
            });
            item.appendChild(pin);
        });

        item.addEventListener("click", function (event) {
            if (event.target && (event.target.classList && event.target.classList.contains("component-value"))) {
                return;
            }

            if (component.type === "S" || component.type === "R" || component.type === "J" || component.type === "K" || component.type === "D" || component.type === "T" || component.type === "CLK") {
                exp3ToggleInputValue(component.type);
            }
        });

        item.addEventListener("mousedown", function (event) {
            if (event.target && event.target.closest && (event.target.closest(".pin") || event.target.closest(".component-value"))) {
                return;
            }

            event.preventDefault();
            const dragState = {
                id: component.id,
                startX: event.clientX,
                startY: event.clientY,
                originX: component.x,
                originY: component.y,
                moved: false
            };

            function onMouseMove(moveEvent) {
                const dx = moveEvent.clientX - dragState.startX;
                const dy = moveEvent.clientY - dragState.startY;
                if (Math.abs(dx) > 3 || Math.abs(dy) > 3) {
                    dragState.moved = true;
                }

                const target = exp3State.components.find(function (item) {
                    return item.id === dragState.id;
                });

                if (target) {
                    target.x = Math.max(10, Math.min(650, dragState.originX + (moveEvent.clientX - dragState.startX)));
                    target.y = Math.max(10, Math.min(430, dragState.originY + (moveEvent.clientY - dragState.startY)));
                    exp3RenderCanvas();
                }
            }

            function onMouseUp() {
                window.removeEventListener("mousemove", onMouseMove);
                window.removeEventListener("mouseup", onMouseUp);
                if (!dragState.moved && (component.type === "S" || component.type === "R" || component.type === "J" || component.type === "K" || component.type === "D" || component.type === "T" || component.type === "CLK")) {
                    exp3ToggleInputValue(component.type);
                }
            }

            window.addEventListener("mousemove", onMouseMove);
            window.addEventListener("mouseup", onMouseUp);
        });

        canvas.appendChild(item);
    });
}

function exp3SetStatus(message, isError) {
    const statusBox = document.getElementById("exp3StatusBox");
    if (!statusBox) {
        return;
    }
    statusBox.dataset.fullStatus = message;
    statusBox.textContent = window.virtualDeldSettings
        ? window.virtualDeldSettings.formatStatus(message)
        : message;
    statusBox.classList.toggle("status-error", Boolean(isError));
}

function exp3GetCurrentInputValues() {
    const state = exp3State.inputValues;
    const selection = exp3GetSelectedDefinition();
    const values = {};
    selection.inputs.forEach(function (name) {
        values[name] = exp3NormalizeSignal(state[name]);
    });
    return values;
}

function exp3ExpectedNextState(type, inputValues, previousQ) {
    const normalizedPrevious = previousQ === null ? 0 : Number(previousQ);
    if (type === "SR") {
        if (inputValues.S === 1 && inputValues.R === 1) {
            return { expected: "Invalid", operation: "Forbidden" };
        }
        if (inputValues.R === 1) {
            return { expected: 0, operation: "Reset" };
        }
        if (inputValues.S === 1) {
            return { expected: 1, operation: "Set" };
        }
        return { expected: normalizedPrevious, operation: "Hold" };
    }

    if (type === "JK") {
        if (inputValues.J === 0 && inputValues.K === 0) {
            return { expected: normalizedPrevious, operation: "Hold" };
        }
        if (inputValues.J === 0 && inputValues.K === 1) {
            return { expected: 0, operation: "Reset" };
        }
        if (inputValues.J === 1 && inputValues.K === 0) {
            return { expected: 1, operation: "Set" };
        }
        return { expected: normalizedPrevious === 1 ? 0 : 1, operation: "Toggle" };
    }

    if (type === "D") {
        return { expected: inputValues.D, operation: inputValues.D === 1 ? "Set to 1" : "Reset to 0" };
    }

    if (type === "T") {
        if (inputValues.T === 0) {
            return { expected: normalizedPrevious, operation: "Hold" };
        }
        return { expected: normalizedPrevious === 1 ? 0 : 1, operation: "Toggle" };
    }

    return { expected: normalizedPrevious, operation: "Hold" };
}

function exp3ComputeNextState() {
    const selected = exp3State.selectedFlipFlop;
    const inputs = exp3GetCurrentInputValues();
    const previousQ = exp3State.currentQ;
    const expected = exp3ExpectedNextState(selected, inputs, previousQ);

    if (selected === "SR") {
        const result = window.flipFlopLogic ? window.flipFlopLogic.srNextState(inputs.S, inputs.R, previousQ) : { nextQ: expected.expected, valid: true, message: "" };
        return { ...result, expected: expected.expected, operation: result.operation || expected.operation };
    }

    if (selected === "JK") {
        const result = window.flipFlopLogic ? window.flipFlopLogic.jkNextState(inputs.J, inputs.K, previousQ) : { nextQ: expected.expected, valid: true };
        return { ...result, expected: expected.expected, operation: result.operation || expected.operation };
    }

    if (selected === "D") {
        const result = window.flipFlopLogic ? window.flipFlopLogic.dNextState(inputs.D) : { nextQ: expected.expected, valid: true };
        return { ...result, expected: expected.expected, operation: result.operation || expected.operation };
    }

    const result = window.flipFlopLogic ? window.flipFlopLogic.tNextState(inputs.T, previousQ) : { nextQ: expected.expected, valid: true };
    return { ...result, expected: expected.expected, operation: result.operation || expected.operation };
}

function exp3ValidateCircuit() {
    if (exp3State.components.length === 0) {
        return { valid: false, message: "No circuit found. Place the required components and connect them before running the simulation." };
    }

    const definition = exp3GetSelectedDefinition();
    const available = exp3State.components.map(function (component) {
        return component.type;
    });

    for (let index = 0; index < definition.required.length; index += 1) {
        const item = definition.required[index];
        if (item === "FF") {
            if (!available.includes("FF")) {
                return { valid: false, message: "Required flip-flop component is missing." };
            }
        }
        if (item !== "FF" && !available.includes(item) && item !== "Q" && item !== "QBar") {
            return { valid: false, message: "Input " + item + " is not connected." };
        }
    }

    const qOutput = exp3State.components.find(function (component) { return component.type === "Q"; });
    const qBarOutput = exp3State.components.find(function (component) { return component.type === "QBar"; });
    if (!qOutput || !qBarOutput) {
        return { valid: false, message: "Both Q and Q̅ output indicators are required." };
    }

    const ffComponent = exp3State.components.find(function (component) { return component.type === "FF"; });
    if (ffComponent) {
        const qConnected = exp3State.connections.some(function (connection) {
            return connection.from === ffComponent.id && connection.fromPort === "Q" &&
                connection.to === qOutput.id && connection.toPort === "input";
        });
        const qBarConnected = exp3State.connections.some(function (connection) {
            return connection.from === ffComponent.id && connection.fromPort === "QBar" &&
                connection.to === qBarOutput.id && connection.toPort === "input";
        });
        if (!qConnected || !qBarConnected) {
            return { valid: false, message: "Connect the flip-flop Q and Q̅ outputs to their matching indicators." };
        }

        const requiredPorts = exp3GetRequiredFFPorts();
        const missingPort = requiredPorts.find(function (portName) {
            return !exp3State.connections.some(function (connection) {
                return connection.to === ffComponent.id && connection.toPort === portName;
            });
        });
        if (missingPort) {
            return { valid: false, message: "Missing connection to the " + missingPort + " input." };
        }
    }

    return { valid: true, message: "Circuit valid." };
}

function exp3MatchRowForCurrentInputs(selected, inputValues) {
    return exp3Definitions[selected].rows.find(function (row) {
        const rowKeys = Object.keys(row).filter(function (key) {
            return key !== "label" && key !== "expected" && key !== "operation";
        });

        return rowKeys.every(function (key) {
            if (inputValues[key] === undefined) {
                return true;
            }
            return Number(inputValues[key]) === Number(row[key]);
        });
    }) || null;
}

function exp3VerifyResult() {
    if (!getVirtualLabSettings().truthTableVerification) {
        exp3SetStatus("Enable Truth Table Verification in Settings before verifying results.", true);
        return;
    }

    if (!exp3State.lastSimulationResult) {
        exp3SetStatus("Apply a clock pulse before attempting verification.", true);
        return;
    }

    const selected = exp3State.selectedFlipFlop;
    const inputValues = exp3GetCurrentInputValues();
    if (JSON.stringify(inputValues) !== JSON.stringify(exp3State.lastSimulationInputs) ||
        exp3State.previousQ !== exp3State.lastSimulationPreviousQ) {
        exp3SetStatus("Apply a new clock pulse for the current inputs before verifying.", true);
        return;
    }
    const rowDefinition = exp3MatchRowForCurrentInputs(selected, inputValues) || {
        label: "Current input",
        expected: exp3State.lastSimulationResult.expected,
        operation: exp3State.lastSimulationResult.operation
    };

    const previousQ = exp3State.previousQ === null ? "Unknown" : exp3State.previousQ;
    const expected = rowDefinition.expected;
    const actual = exp3State.lastSimulationResult.nextQ;
    let verified = false;

    if (expected === "Invalid") {
        verified = exp3State.lastSimulationResult.valid === false;
    } else if (expected === "Q(previous)" || expected === "NOT Q(previous)") {
        const expectedValue = expected === "Q(previous)" ? previousQ : (previousQ === 1 ? 0 : 1);
        verified = Number(actual) === Number(expectedValue);
    } else {
        verified = Number(actual) === Number(expected);
    }

    const record = {
        label: rowDefinition.label,
        inputs: JSON.stringify(inputValues),
        previousQ: previousQ,
        expected: expected,
        obtained: actual,
        verified: verified,
        status: verified ? "✓ Correct" : "✗ Incorrect",
        operation: exp3State.lastSimulationResult.operation || rowDefinition.operation
    };

    const existingIndex = exp3State.truthResults[selected].findIndex(function (item) {
        return item.label === record.label;
    });
    if (existingIndex !== -1) {
        exp3State.truthResults[selected][existingIndex] = record;
    } else {
        exp3State.truthResults[selected].push(record);
    }

    const requiredCount = exp3Definitions[selected].rows.length;
    const verifiedCount = exp3State.truthResults[selected].filter(function (item) {
        return item.verified;
    }).length;

    exp3State.progress[selected] = verifiedCount;
    exp3State.completed[selected] = verifiedCount >= requiredCount;
    exp3RenderTruthTable();
    exp3RenderProgress();

    if (verified) {
        exp3SetStatus("Correct: observed output matches the expected result.", false);
    } else {
        exp3SetStatus("Output mismatch. Review your circuit and input settings.", true);
    }
}

function exp3ApplyClockPulse() {
    if (!exp3State.initialized) {
        exp3SetStatus("State not initialized. Use Reset / Initialize before applying the clock pulse.", true);
        return;
    }

    const validation = exp3ValidateCircuit();
    if (!validation.valid) {
        setCircuitValidationError(exp3SetStatus, validation);
        return;
    }

    const selected = exp3State.selectedFlipFlop;
    exp3State.previousClock = exp3State.clockState;
    exp3State.clockState = 1;
    const edgeDetected = window.flipFlopLogic ? window.flipFlopLogic.clockEdgeDetected(exp3State.previousClock, exp3State.clockState) : true;

    if (!edgeDetected) {
        exp3SetStatus("Clock is not on an active edge. No state transition occurred.", false);
        exp3UpdateSimulationPanel();
        return;
    }

    exp3State.previousQ = exp3State.currentQ;
    const result = exp3ComputeNextState();

    if (result.valid === false) {
        exp3State.currentQ = exp3State.previousQ === null ? 0 : exp3State.previousQ;
        exp3State.lastOperation = result.message || "Invalid SR Input\nS and R cannot both be HIGH in this implementation.";
        exp3SetStatus(result.message || "Invalid SR Input\nS and R cannot both be HIGH in this implementation.", true);
    } else {
        exp3State.currentQ = result.nextQ;
        exp3State.lastOperation = result.operation || "State updated.";
        const outputDetails = getVirtualLabSettings().showOutputValues
            ? "\nPrevious Q: " + (exp3State.previousQ === null ? "Unknown" : exp3State.previousQ) + "\nCurrent Q: " + exp3State.currentQ
            : "";
        exp3SetStatus("Clock pulse applied." + outputDetails + "\nOperation: " + result.operation, false);
    }

    exp3State.qBar = exp3State.currentQ === 1 ? 0 : 1;
    exp3State.clockState = 0;
    exp3State.lastSimulationResult = result;
    exp3State.lastSimulationLabel = exp3MatchRowForCurrentInputs(selected, exp3GetCurrentInputValues());
    exp3State.lastSimulationInputs = exp3GetCurrentInputValues();
    exp3State.lastSimulationPreviousQ = exp3State.previousQ;
    exp3RenderCanvas();
    exp3UpdateSimulationPanel();
    exp3RenderTruthTable();
    if (getVirtualLabSettings().truthTableVerification) {
        exp3VerifyResult();
    }
}

function exp3RunSimulation() {
    if (!exp3State.initialized) {
        exp3SetStatus("State not initialized. Use Reset / Initialize before running the simulation.", true);
        return;
    }

    const validation = exp3ValidateCircuit();
    if (!validation.valid) {
        setCircuitValidationError(exp3SetStatus, validation);
        return;
    }

    const result = exp3ComputeNextState();
    if (result.valid === false) {
        exp3SetStatus(result.message || "Invalid inputs. No state transition occurred.", true);
    } else {
        exp3SetStatus(
            "Inputs are valid. Q remains unchanged until you apply the clock pulse." +
            (getVirtualLabSettings().showOutputValues ? " Expected next Q: " + result.nextQ + "." : ""),
            false
        );
    }
    exp3UpdateSimulationPanel();
}

function exp3RenderTruthTable() {
    const tbody = document.getElementById("exp3TruthTableBody");
    if (!tbody) {
        return;
    }

    const selected = exp3State.selectedFlipFlop;
    const rows = exp3Definitions[selected].rows;
    tbody.innerHTML = rows.map(function (row) {
        const matched = exp3State.truthResults[selected].find(function (item) {
            return item.label === row.label;
        });

        const previousQ = matched && matched.previousQ !== undefined ? matched.previousQ : (exp3State.previousQ === null ? "Unknown" : exp3State.previousQ);
        const expected = row.expected;
        const obtained = matched && matched.obtained !== undefined ? matched.obtained : "—";
        const status = matched && matched.verified !== undefined
            ? (matched.verified ? "✓ Correct" : "✗ Incorrect")
            : (matched && matched.obtained !== undefined ? "Awaiting verification" : "Not tested");

        const inputText = selected === "SR" ? "S=" + row.S + ", R=" + row.R : selected === "JK" ? "J=" + row.J + ", K=" + row.K : selected === "D" ? "D=" + row.D : "T=" + row.T;
        return "<tr><td>" + inputText + "</td><td>" + previousQ + "</td><td>" + expected + "</td><td>" + obtained + "</td><td>" + status + "</td></tr>";
    }).join("");
}

function exp3UpdateSimulationPanel() {
    const selected = exp3State.selectedFlipFlop;
    const definition = exp3Definitions[selected];
    const selectedNode = document.getElementById("exp3SelectedFlipFlop");
    const currentQNode = document.getElementById("exp3CurrentQ");
    const previousQNode = document.getElementById("exp3PreviousQ");
    const qBarNode = document.getElementById("exp3QBarValue");
    const clockNode = document.getElementById("exp3ClockValue");
    const inputReadout = document.getElementById("exp3InputReadout");

    if (selectedNode) {
        selectedNode.textContent = definition.label;
    }
    if (currentQNode) {
        currentQNode.textContent = String(exp3State.currentQ);
    }
    if (previousQNode) {
        previousQNode.textContent = exp3State.previousQ === null ? "Unknown" : String(exp3State.previousQ);
    }
    if (qBarNode) {
        qBarNode.textContent = String(exp3State.qBar);
    }
    if (clockNode) {
        clockNode.textContent = String(exp3State.clockState);
    }

    if (inputReadout) {
        const values = exp3GetCurrentInputValues();
        const labels = [];
        definition.inputs.forEach(function (name) {
            labels.push(name + ": " + values[name]);
        });
        inputReadout.innerHTML = "<span>" + labels.join(" | ") + "</span>";
    }
}

function exp3RenderProgress() {
    const node = document.getElementById("exp3ProgressStatus");
    if (!node) {
        return;
    }

    const status = [
        "SR " + (exp3State.completed.SR ? "Completed" : "Not started"),
        "JK " + (exp3State.completed.JK ? "Completed" : "Not started"),
        "D " + (exp3State.completed.D ? "Completed" : "Not started"),
        "T " + (exp3State.completed.T ? "Completed" : "Not started")
    ].join("  ");

    node.textContent = status;
}

function exp3SwitchFlipFlop(type) {
    exp3State.selectedFlipFlop = type;
    exp3State.inputValues = { S: 0, R: 0, J: 0, K: 0, D: 0, T: 0, CLK: 0 };
    exp3State.previousQ = exp3State.currentQ;
    exp3State.clockState = 0;
    exp3State.lastSimulationResult = null;
    exp3State.lastSimulationLabel = null;
    exp3State.lastSimulationInputs = null;
    exp3State.lastSimulationPreviousQ = null;
    exp3State.lastOperation = "Selected " + type + " filter.";
    const guideState = exp3GetGuidedProgress(type);
    guideState.currentStep = 1;
    guideState.completedSteps = [];
    exp3RenderCanvas();
    exp3RenderTruthTable();
    exp3UpdateSimulationPanel();
    exp3RenderProgress();
    exp3RenderGuidedMode();
    exp3SetStatus("Selected flip-flop: " + type + ".", false);
    const buttons = document.querySelectorAll("[data-flipflop]");
    buttons.forEach(function (button) {
        button.classList.toggle("active", button.dataset.flipflop === type);
    });
}

function exp3OpenWorkspace() {
    const detailPanel = document.querySelector(".experiment-detail-panel");
    const workspace = document.getElementById("exp03Workspace");
    if (detailPanel) {
        detailPanel.style.display = "none";
    }
    if (workspace) {
        workspace.classList.remove("hidden");
    }
    exp3RenderCanvas();
    exp3RenderTruthTable();
    exp3UpdateSimulationPanel();
    exp3RenderProgress();
    exp3RenderGuidedMode();
}

function exp3CloseWorkspace() {
    const detailPanel = document.querySelector(".experiment-detail-panel");
    const workspace = document.getElementById("exp03Workspace");
    if (detailPanel) {
        detailPanel.style.display = "block";
    }
    if (workspace) {
        workspace.classList.add("hidden");
    }
}

function exp3AttachEvents() {
    const startButton = document.getElementById("startExp3Btn");
    const backButton = document.getElementById("backToExp3Btn");
    const runButton = document.getElementById("exp3RunSimulationBtn");
    const pulseButton = document.getElementById("exp3ClockPulseBtn");
    const resetButton = document.getElementById("exp3ResetBtn");
    const initializeButton = document.getElementById("exp3ResetBtnSecondary");
    const selectorButtons = document.querySelectorAll("[data-flipflop]");
    const verifyButton = document.getElementById("exp3VerifyBtn");

    if (startButton) {
        startButton.addEventListener("click", function () {
            exp3OpenWorkspace();
        });
    }

    if (backButton) {
        backButton.addEventListener("click", exp3CloseWorkspace);
    }

    if (runButton) {
        runButton.addEventListener("click", exp3RunSimulation);
    }

    if (pulseButton) {
        pulseButton.addEventListener("click", exp3ApplyClockPulse);
    }

    if (verifyButton) {
        verifyButton.addEventListener("click", exp3VerifyResult);
    }

    if (resetButton) {
        resetButton.addEventListener("click", exp3ClearCircuit);
    }

    if (initializeButton) {
        initializeButton.addEventListener("click", function () {
            exp3ResetSequentialState();
        });
    }

    selectorButtons.forEach(function (button) {
        button.addEventListener("click", function () {
            exp3SwitchFlipFlop(button.dataset.flipflop);
        });
    });

    document.querySelectorAll(".exp3-library-item").forEach(function (button) {
        button.addEventListener("click", function () {
            const type = button.dataset.library;
            if (type === "FF") {
                exp3AddComponent("FF");
                return;
            }
            if (type === "Q") {
                exp3AddComponent("Q");
                return;
            }
            if (type === "QBar") {
                exp3AddComponent("QBar");
                return;
            }
            if ((exp3State.selectedFlipFlop === "SR" && (type === "S" || type === "R" || type === "CLK")) || (exp3State.selectedFlipFlop === "JK" && (type === "J" || type === "K" || type === "CLK")) || (exp3State.selectedFlipFlop === "D" && (type === "D" || type === "CLK")) || (exp3State.selectedFlipFlop === "T" && (type === "T" || type === "CLK"))) {
                exp3AddComponent(type);
            }
        });
    });
}

function isGateType(type) {
    return Object.prototype.hasOwnProperty.call(gateMeta, type);
}

function getInputValue(type) {
    return type === "inputA" ? 0 : 1;
}

function getComponentById(id) {
    return exp1State.components.find(function (component) {
        return component.id === id;
    });
}

function getGateComponent(gateName) {
    return exp1State.components.find(function (component) {
        return component.type === gateName;
    });
}

function getInputComponent(type) {
    return exp1State.components.find(function (component) {
        return component.type === type;
    });
}

function getTruthExpected(gateName, values) {
    const a = Number(values[0]);
    const b = Number(values[1] !== undefined ? values[1] : 0);

    if (gateName === "NOT") {
        return gateLogic.NOT(a);
    }

    return gateLogic[gateName](a, b);
}

function getComponentLabel(type) {
    const labels = {
        inputA: "Input A",
        inputB: "Input B",
        Cin: "Carry In",
        AND: "AND",
        OR: "OR",
        XOR: "XOR",
        NOT: "NOT",
        NAND: "NAND",
        NOR: "NOR",
        XNOR: "XNOR",
        LED: "LED",
        SUM: "SUM",
        CARRY: "CARRY"
    };

    return labels[type] || type;
}

function createComponent(type, x, y) {
    clearExp1Results();
    const component = {
        id: "comp-" + Date.now() + Math.random().toString(16).slice(2),
        type: type,
        x: x,
        y: y,
        value: type === "inputA" || type === "inputB" ? getInputValue(type) : 0,
        label: getComponentLabel(type)
    };

    exp1State.components.push(component);
    renderCircuitCanvas();
    renderTruthTable();
    renderProgress();
}

function removeComponent(componentId) {
    clearExp1Results();
    exp1State.components = exp1State.components.filter(function (component) {
        return component.id !== componentId;
    });

    exp1State.connections = exp1State.connections.filter(function (connection) {
        return connection.from !== componentId && connection.to !== componentId;
    });

    renderCircuitCanvas();
    renderTruthTable();
    renderProgress();
}

function setStatus(message, isError) {
    const statusBox = document.getElementById("statusBox");
    if (!statusBox) {
        return;
    }

    statusBox.dataset.fullStatus = message;
    statusBox.textContent = window.virtualDeldSettings
        ? window.virtualDeldSettings.formatStatus(message)
        : message;
    statusBox.classList.toggle("status-error", Boolean(isError));
}

function clearExp1Results() {
    Object.keys(exp1State.truthResults).forEach(function (gateName) {
        exp1State.truthResults[gateName] = {};
    });
    Object.keys(exp1State.completed).forEach(function (gateName) {
        exp1State.completed[gateName] = false;
    });
    const outputValue = document.getElementById("outputValue");
    const ledState = document.getElementById("ledState");
    if (outputValue) {
        outputValue.textContent = "-";
    }
    if (ledState) {
        ledState.textContent = "OFF";
    }
    exp1State.components.forEach(function (component) {
        if (component.type === "LED") {
            component.value = 0;
        }
    });
}

function renderProgress() {
    const progressNode = document.getElementById("progressStatus");
    if (!progressNode) {
        return;
    }

    const progressText = Object.keys(exp1State.completed).map(function (gateName) {
        return gateName + " " + (exp1State.completed[gateName] ? "✓" : "○");
    }).join(" ");

    progressNode.textContent = progressText;

    const completedAll = Object.values(exp1State.completed).every(Boolean);
    if (completedAll) {
        setStatus("Experiment Completed\n✓ Circuit constructed\n✓ Connections verified\n✓ Truth tables verified\n✓ All seven gates completed", false);
    }
}

function getCurrentInputValues() {
    const inputA = getInputComponent("inputA");
    const inputB = getInputComponent("inputB");
    return {
        A: inputA ? Number(inputA.value) : 0,
        B: inputB ? Number(inputB.value) : 0
    };
}

function getGateInputRows(gateName) {
    const rows = gateMeta[gateName].rows;
    return rows.map(function (row) {
        const expected = getTruthExpected(gateName, row);
        const key = row.join("-");
        const obtained = exp1State.truthResults[gateName][key];
        const status = obtained === undefined ? "-" : (Number(obtained) === expected ? "✓ Correct" : "✗ Incorrect");
        return {
            values: row,
            expected: expected,
            obtained: obtained === undefined ? "-" : String(obtained),
            status: status,
            key: key
        };
    });
}

function renderTruthTable() {
    const tbody = document.getElementById("truthTableBody");
    if (!tbody) {
        return;
    }

    const rows = getGateInputRows(exp1State.selectedGate);
    tbody.innerHTML = rows.map(function (row) {
        const firstValue = row.values[0] !== undefined ? row.values[0] : 0;
        const secondValue = row.values[1] !== undefined ? row.values[1] : 0;
        const obtainedCell = row.obtained === "-" ? "-" : String(row.obtained);

        return "<tr><td>" + firstValue + "</td><td>" + secondValue + "</td><td>" + row.expected + "</td><td>" + obtainedCell + "</td><td>" + row.status + "</td></tr>";
    }).join("");
}

function getPinCoordinates(component, port) {
    const canvas = document.getElementById("circuitCanvas");
    if (!canvas) {
        return { x: component.x, y: component.y };
    }

    const item = canvas.querySelector('[data-id="' + component.id + '"]');
    if (!item) {
        const width = component.type === "LED" ? 76 : component.type === "inputA" || component.type === "inputB" ? 90 : 110;
        const height = component.type === "LED" ? 70 : 52;
        const x = component.x;
        const y = component.y;

        if (port === "input1") {
            return { x: x + 6, y: y + height / 2 - 3 };
        }

        if (port === "input2") {
            return { x: x + 6, y: y + height / 2 + 18 };
        }

        if (port === "input") {
            return { x: x + 6, y: y + height / 2 };
        }

        return { x: x + width - 6, y: y + height / 2 };
    }

    const pin = item.querySelector('.pin.' + port);
    if (!pin) {
        return { x: component.x, y: component.y };
    }

    const canvasRect = canvas.getBoundingClientRect();
    const pinRect = pin.getBoundingClientRect();
    const centerX = pinRect.left - canvasRect.left + pinRect.width / 2;
    const centerY = pinRect.top - canvasRect.top + pinRect.height / 2;

    return { x: centerX, y: centerY };
}

function renderCircuitCanvas() {
    const canvas = document.getElementById("circuitCanvas");
    if (!canvas) {
        return;
    }

    canvas.innerHTML = "";
    canvas.style.position = "relative";

    const svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
    svg.setAttribute("viewBox", "0 0 800 520");
    svg.setAttribute("width", "100%");
    svg.setAttribute("height", "100%");
    svg.style.position = "absolute";
    svg.style.left = "0";
    svg.style.top = "0";
    svg.style.width = "100%";
    svg.style.height = "100%";
    svg.style.pointerEvents = "none";
    svg.style.zIndex = "1";
    canvas.appendChild(svg);

    exp1State.components.forEach(function (component) {
        const item = document.createElement("div");
        item.className = "circuit-component " + component.type;
        item.style.left = component.x + "px";
        item.style.top = component.y + "px";
        item.setAttribute("data-id", component.id);
        item.setAttribute("title", component.label);

        const label = document.createElement("div");
        label.className = "component-label";
        label.textContent = component.label;
        item.appendChild(label);

        let valueText = "";
        if (component.type === "inputA" || component.type === "inputB") {
            valueText = "A: " + component.value + "";
            if (component.type === "inputB") {
                valueText = "B: " + component.value + "";
            }
        } else if (component.type === "LED") {
            valueText = component.value ? "ON" : "OFF";
        }

        if (valueText) {
            const valueNode = document.createElement("div");
            valueNode.className = component.type === "LED"
                ? "component-value output-value"
                : "component-value";
            valueNode.textContent = valueText;
            item.appendChild(valueNode);
        }

        const pins = [];
        if (isGateType(component.type) && component.type !== "NOT") {
            pins.push({ port: "input1", label: "1" });
            pins.push({ port: "input2", label: "2" });
            pins.push({ port: "output", label: "out" });
        } else if (component.type === "NOT") {
            pins.push({ port: "input", label: "in" });
            pins.push({ port: "output", label: "out" });
        } else if (component.type === "inputA" || component.type === "inputB") {
            pins.push({ port: "output", label: "out" });
        } else if (component.type === "LED") {
            pins.push({ port: "input", label: "in" });
        }

        pins.forEach(function (pinInfo) {
            const pin = document.createElement("button");
            pin.type = "button";
            pin.className = "pin " + pinInfo.port;
            pin.dataset.componentId = component.id;
            pin.dataset.port = pinInfo.port;
            pin.textContent = pinInfo.label;
            pin.addEventListener("click", function (event) {
                event.stopPropagation();
                handlePinClick(component.id, pinInfo.port);
            });
            item.appendChild(pin);
        });

        item.addEventListener("click", function () {
            if (component.type === "inputA" || component.type === "inputB") {
                component.value = component.value === 1 ? 0 : 1;
                renderCircuitCanvas();
                renderTruthTable();
                scheduleCombinationalAutoRun(validateCircuit, runSimulation);
                return;
            }

            if (component.type === "LED") {
                component.value = component.value === 1 ? 0 : 1;
                renderCircuitCanvas();
                return;
            }

            if (isGateType(component.type)) {
                exp1State.selectedGate = component.type;
                updateGateButtons();
                renderTruthTable();
                renderProgress();
            }
        });

        item.addEventListener("dblclick", function () {
            removeComponent(component.id);
        });

        item.addEventListener("mousedown", function (event) {
            if (event.target.tagName === "BUTTON") {
                return;
            }

            const dragState = {
                id: component.id,
                startX: event.clientX,
                startY: event.clientY,
                originX: component.x,
                originY: component.y
            };

            function onMouseMove(moveEvent) {
                const dx = moveEvent.clientX - dragState.startX;
                const dy = moveEvent.clientY - dragState.startY;
                const target = getComponentById(dragState.id);
                if (target) {
                    target.x = Math.max(10, Math.min(650, dragState.originX + dx));
                    target.y = Math.max(10, Math.min(430, dragState.originY + dy));
                    renderCircuitCanvas();
                }
            }

            function onMouseUp() {
                window.removeEventListener("mousemove", onMouseMove);
                window.removeEventListener("mouseup", onMouseUp);
            }

            window.addEventListener("mousemove", onMouseMove);
            window.addEventListener("mouseup", onMouseUp);
        });

        canvas.appendChild(item);
    });

    exp1State.connections.forEach(function (connection) {
        const fromComponent = getComponentById(connection.from);
        const toComponent = getComponentById(connection.to);

        if (!fromComponent || !toComponent) {
            return;
        }

        const fromPoint = getPinCoordinates(fromComponent, "output");
        const toPoint = getPinCoordinates(toComponent, connection.toPort);

        const line = document.createElementNS("http://www.w3.org/2000/svg", "path");
        line.setAttribute("d", "M " + fromPoint.x + " " + fromPoint.y + " C " + (fromPoint.x + 60) + " " + fromPoint.y + ", " + (toPoint.x - 60) + " " + toPoint.y + ", " + toPoint.x + " " + toPoint.y);
        line.setAttribute("fill", "none");
        line.setAttribute("stroke", "#4d7d58");
        line.setAttribute("stroke-width", "3");
        svg.appendChild(line);
    });
}

function handlePinClick(componentId, port) {
    const component = getComponentById(componentId);
    if (!component) {
        return;
    }

    if (!exp1State.pendingConnection) {
        exp1State.pendingConnection = { from: componentId, fromPort: port };
        setStatus("Select a destination input to complete the connection.", false);
        return;
    }

    if (exp1State.pendingConnection.from === componentId) {
        exp1State.pendingConnection = null;
        setCircuitValidationError(setStatus, { message: "Invalid Connection\nA component cannot connect to itself." });
        return;
    }

    const fromComponent = getComponentById(exp1State.pendingConnection.from);
    const targetComponent = component;

    if (!fromComponent || !targetComponent) {
        exp1State.pendingConnection = null;
        return;
    }

    const result = validateConnection(fromComponent, exp1State.pendingConnection.fromPort, targetComponent, port);
    if (!result.valid) {
        setCircuitValidationError(setStatus, result);
        exp1State.pendingConnection = null;
        return;
    }

    const alreadyDriven = exp1State.connections.some(function (connection) {
        return connection.to === targetComponent.id && connection.toPort === port;
    });

    if (alreadyDriven) {
        exp1State.pendingConnection = null;
        setCircuitValidationError(setStatus, { message: "Multiple drivers are not allowed on one input terminal." });
        return;
    }

    const wouldCycle = exp1State.connections.some(function (connection) {
        return connection.from === targetComponent.id && connection.to === fromComponent.id;
    });
    if (wouldCycle || hasCircuitCycle(exp1State.components, exp1State.connections.concat([{
        from: fromComponent.id,
        to: targetComponent.id
    }]))) {
        exp1State.pendingConnection = null;
        setCircuitValidationError(setStatus, { message: "Circular dependency detected. Check the circuit connections." });
        return;
    }

    exp1State.connections.push({
        from: fromComponent.id,
        fromPort: exp1State.pendingConnection.fromPort,
        to: targetComponent.id,
        toPort: port
    });
    clearExp1Results();
    setStatus("Connection successful.", false);
    exp1State.pendingConnection = null;
    renderCircuitCanvas();
}

function validateConnection(fromComponent, fromPort, toComponent, toPort) {
    if (fromPort !== "output") {
        return { valid: false, message: "Invalid Connection\nStart each wire from an output terminal." };
    }

    const validTargetPorts = toComponent.type === "NOT"
        ? ["input"]
        : isGateType(toComponent.type)
            ? ["input1", "input2"]
            : toComponent.type === "LED"
                ? ["input"]
                : [];
    if (!validTargetPorts.includes(toPort)) {
        return { valid: false, message: "Invalid Connection\nConnect an output terminal to a compatible input terminal." };
    }

    if (fromComponent.type === "LED") {
        return { valid: false, message: "Invalid Connection\nLED cannot be used as a source component." };
    }

    if (toComponent.type === "LED" && (!isGateType(fromComponent.type) || fromPort !== "output")) {
        return { valid: false, message: "Invalid Connection\nConnect a gate output to the LED input." };
    }

    if (fromComponent.type === "inputA" || fromComponent.type === "inputB") {
        if (toComponent.type === "inputA" || toComponent.type === "inputB") {
            return { valid: false, message: "Invalid Connection\nAn input component cannot be connected to another input." };
        }

        if (toComponent.type === "LED") {
            return { valid: false, message: "Invalid Connection\nInput cannot be connected directly to an LED." };
        }

        if (isGateType(toComponent.type)) {
            return { valid: true, message: "Connection successful." };
        }
    }

    if (isGateType(fromComponent.type)) {
        if (toComponent.type === "LED") {
            return { valid: true, message: "Connection successful." };
        }

        if (isGateType(toComponent.type)) {
            return { valid: true, message: "Connection successful." };
        }
    }

    if (toComponent.type === "LED") {
        if (fromPort !== "output") {
            return { valid: false, message: "Invalid Connection\nLED input must receive a gate output." };
        }
    }

    if (fromComponent.type === "LED") {
        return { valid: false, message: "Invalid Connection\nLED cannot be connected to another component." };
    }

    return { valid: false, message: "Invalid Connection\nThis connection is not allowed in the current circuit." };
}

function evaluateComponent(componentId, visited) {
    const path = new Set(visited || []);
    if (path.has(componentId)) {
        return null;
    }
    path.add(componentId);
    const component = getComponentById(componentId);
    if (!component) {
        return null;
    }

    if (component.type === "inputA" || component.type === "inputB") {
        return component.value;
    }

    if (component.type === "LED") {
        const incoming = exp1State.connections.filter(function (connection) {
            return connection.to === component.id && connection.toPort === "input";
        });

        if (incoming.length !== 1) {
            return null;
        }

        const source = getComponentById(incoming[0].from);
        if (!source) {
            return null;
        }

        return evaluateComponent(source.id, path);
    }

    if (isGateType(component.type)) {
        const ports = component.type === "NOT" ? ["input"] : ["input1", "input2"];
        const values = ports.map(function (port) {
            const incoming = exp1State.connections.filter(function (connection) {
                return connection.to === component.id && connection.toPort === port;
            });
            if (incoming.length !== 1) {
                return null;
            }
            const source = getComponentById(incoming[0].from);
            return source ? evaluateComponent(source.id, path) : null;
        });

        if (values.some(function (value) { return value !== 0 && value !== 1; })) {
            return null;
        }
        if (component.type === "NOT") {
            return gateLogic.NOT(values[0]);
        }
        return gateLogic[component.type](values[0], values[1]);
    }

    return null;
}

function validateCircuit() {
    const gateName = exp1State.selectedGate;
    const gateComponent = getGateComponent(gateName);

    if (!gateComponent) {
        return { valid: false, message: "⚠ No Circuit\nPlace the required components and connect them before running the simulation." };
    }

    if (hasCircuitCycle(exp1State.components, exp1State.connections)) {
        return { valid: false, message: "Circular dependency detected. Check the circuit connections." };
    }

    const inputA = getInputComponent("inputA");
    if (!inputA) {
        return { valid: false, message: "Input A is missing. Place Input A before simulation." };
    }
    const inputB = getInputComponent("inputB");
    if (gateMeta[gateName].inputs === 2 && !inputB) {
        return { valid: false, message: "Input B is missing. Place Input B before simulation." };
    }

    const requiredPorts = gateName === "NOT" ? ["input"] : ["input1", "input2"];
    const gateInputs = exp1State.connections.filter(function (connection) {
        return connection.to === gateComponent.id;
    });
    if (gateInputs.length !== requiredPorts.length) {
        return { valid: false, message: gateName + " gate has missing or extra input connections." };
    }
    for (let index = 0; index < requiredPorts.length; index += 1) {
        const port = requiredPorts[index];
        const connection = gateInputs.find(function (item) {
            return item.toPort === port;
        });
        if (!connection) {
            return { valid: false, message: "Input " + (index === 0 ? "A" : "B") + " is not connected." };
        }
        const expectedSource = index === 0 ? inputA : inputB;
        if (!expectedSource || connection.from !== expectedSource.id || connection.fromPort !== "output") {
            return { valid: false, message: "Connect " + (index === 0 ? "Input A" : "Input B") + " to the matching gate input." };
        }
    }

    const duplicatedInputs = new Set();
    for (let index = 0; index < exp1State.connections.length; index += 1) {
        const connection = exp1State.connections[index];
        const key = connection.to + ":" + connection.toPort;
        if (duplicatedInputs.has(key)) {
            return { valid: false, message: "Multiple drivers are connected to one input." };
        }
        duplicatedInputs.add(key);
    }

    const ledComponent = exp1State.components.find(function (component) {
        return component.type === "LED";
    });

    if (!ledComponent) {
        return { valid: false, message: "⚠ No Output\nPlace the LED before running the simulation." };
    }

    const ledConnections = exp1State.connections.filter(function (connection) {
        return connection.to === ledComponent.id && connection.toPort === "input";
    });
    if (ledConnections.length !== 1 ||
        ledConnections[0].from !== gateComponent.id ||
        ledConnections[0].fromPort !== "output") {
        return { valid: false, message: "⚠ Output Not Connected\nConnect the gate output to the LED before running the simulation." };
    }

    return { valid: true, message: "Circuit valid." };
}

function updateGateButtons() {
    const buttons = document.querySelectorAll(".gate-btn");
    buttons.forEach(function (button) {
        button.classList.toggle("active", button.dataset.gate === exp1State.selectedGate);
    });
    const guide = document.getElementById("guidedBox");
    if (guide) {
        const gate = exp1State.selectedGate;
        guide.innerHTML = gate === "NOT"
            ? "Step 1: Place Input A and a NOT gate.<br>Step 2: Connect Input A to the NOT input.<br>Step 3: Place an LED and connect the NOT output to it.<br>Step 4: Test A = 0 and A = 1 using Run Simulation."
            : "Step 1: Place Input A and Input B.<br>Step 2: Place a " + gate + " gate.<br>Step 3: Connect A and B to the gate's two inputs.<br>Step 4: Connect the gate output to an LED.<br>Step 5: Test all input combinations using Run Simulation.";
    }
}

function updateCompletedState(gateName) {
    const rows = gateMeta[gateName].rows;
    const allCorrect = rows.every(function (row) {
        const key = row.join("-");
        const obtained = exp1State.truthResults[gateName][key];
        return obtained !== undefined && Number(obtained) === getTruthExpected(gateName, row);
    });

    exp1State.completed[gateName] = allCorrect;
}

function runSimulation() {
    const validation = validateCircuit();
    if (!validation.valid) {
        setCircuitValidationError(setStatus, validation);
        return;
    }

    const gateName = exp1State.selectedGate;
    const inputValues = getCurrentInputValues();
    const actualA = inputValues.A;
    const actualB = inputValues.B;

    const ledComponent = exp1State.components.find(function (component) {
        return component.type === "LED";
    });
    const result = ledComponent ? evaluateComponent(ledComponent.id, new Set()) : 0;
    const key = gateName === "NOT" ? String(actualA) : actualA + "-" + actualB;
    const expected = gateName === "NOT" ? gateLogic.NOT(actualA) : gateLogic[gateName](actualA, actualB);
    const isCorrect = result === expected;
    const truthVerificationEnabled = getVirtualLabSettings().truthTableVerification;
    if (truthVerificationEnabled) {
        exp1State.truthResults[gateName][key] = result;
        updateCompletedState(gateName);
    }

    if (ledComponent) {
        ledComponent.value = result;
    }

    const outputValue = document.getElementById("outputValue");
    const ledState = document.getElementById("ledState");

    if (outputValue) {
        outputValue.textContent = String(result);
    }

    if (ledState) {
        ledState.textContent = result === 1 ? "ON" : "OFF";
    }

    renderTruthTable();
    renderProgress();
    renderCircuitCanvas();

    if (!getVirtualLabSettings().showOutputValues) {
        setStatus(truthVerificationEnabled
            ? (isCorrect ? "✓ Simulation successful." : "✗ Output mismatch. Check the circuit and input connections.")
            : "Simulation complete.", !isCorrect && truthVerificationEnabled);
    } else if (!truthVerificationEnabled) {
        setStatus("Simulation complete.\nOutput: " + result + "\nLED: " + (result === 1 ? "ON" : "OFF"), false);
    } else if (isCorrect) {
        setStatus("✓ Simulation successful\nOutput: " + result + "\nLED: " + (result === 1 ? "ON" : "OFF"), false);
    } else {
        setStatus("✗ Incorrect\nExpected: " + expected + "\nObtained: " + result, true);
    }
}

function resetCircuit() {
    exp1State.components = [];
    exp1State.connections = [];
    exp1State.pendingConnection = null;
    clearExp1Results();
    exp1State.selectedGate = "AND";
    updateGateButtons();
    setStatus("Ready for simulation.", false);
    renderCircuitCanvas();
    renderTruthTable();
    renderProgress();
}

function openExperimentWorkspace() {
    const detailPanel = document.querySelector(".experiment-detail-panel");
    const workspace = document.getElementById("exp01Workspace");
    if (detailPanel) {
        detailPanel.style.display = "none";
    }
    if (workspace) {
        workspace.classList.remove("hidden");
    }
}

function closeExperimentWorkspace() {
    const detailPanel = document.querySelector(".experiment-detail-panel");
    const workspace = document.getElementById("exp01Workspace");
    if (detailPanel) {
        detailPanel.style.display = "block";
    }
    if (workspace) {
        workspace.classList.add("hidden");
    }
}

function attachExperimentOneEvents() {
    const startButton = document.getElementById("startAssignmentBtn");
    const backButton = document.getElementById("backToExperimentBtn");
    const runButton = document.getElementById("runSimulationBtn");
    const resetButton = document.getElementById("resetCircuitBtn");
    const gateButtons = document.querySelectorAll(".gate-btn");
    const libraryButtons = document.querySelectorAll(".library-item");
    const modeButtons = document.querySelectorAll(".mode-btn");

    if (startButton) {
        startButton.addEventListener("click", openExperimentWorkspace);
    }

    if (backButton) {
        backButton.addEventListener("click", closeExperimentWorkspace);
    }

    if (runButton) {
        runButton.addEventListener("click", runSimulation);
    }

    if (resetButton) {
        resetButton.addEventListener("click", resetCircuit);
    }

    gateButtons.forEach(function (button) {
        button.addEventListener("click", function () {
            exp1State.selectedGate = button.dataset.gate;
            updateGateButtons();
            renderTruthTable();
            setStatus("Selected gate: " + exp1State.selectedGate + ".", false);
        });
    });

    libraryButtons.forEach(function (button) {
        button.addEventListener("click", function () {
            const type = button.dataset.library;
            if (type === "inputA") {
                createComponent("inputA", 80, 140);
            } else if (type === "inputB") {
                createComponent("inputB", 80, 240);
            } else if (type === "LED") {
                createComponent("LED", 600, 180);
            } else if (isGateType(type)) {
                createComponent(type, 260, 150);
            }
        });
    });

    modeButtons.forEach(function (button) {
        button.addEventListener("click", function () {
            modeButtons.forEach(function (item) {
                item.classList.toggle("active", item === button);
            });
        });
    });
}

function exp2GetComponentById(id) {
    return exp2State.components.find(function (component) {
        return component.id === id;
    });
}

function exp2HasConnection(from, to, toPort) {
    return exp2State.connections.some(function (connection) {
        return connection.from === from.id &&
            connection.fromPort === "output" &&
            connection.to === to.id &&
            (toPort === undefined || connection.toPort === toPort);
    });
}

function exp2GateHasInputs(gate, sourceIds) {
    const incoming = exp2State.connections.filter(function (connection) {
        return connection.to === gate.id;
    });
    return incoming.length === 2 &&
        incoming.every(function (connection) {
            return connection.fromPort === "output" &&
                ["input1", "input2"].includes(connection.toPort);
        }) &&
        new Set(incoming.map(function (connection) { return connection.toPort; })).size === 2 &&
        new Set(incoming.map(function (connection) { return connection.from; })).size === 2 &&
        sourceIds.every(function (id) {
            return incoming.some(function (connection) { return connection.from === id; });
        });
}

function exp2GetInputValue(type) {
    const row = type === "inputA" ? "A" : type === "inputB" ? "B" : "Cin";
    const component = exp2State.components.find(function (item) {
        return item.type === type;
    });
    return component ? Number(component.value) : (row === "Cin" ? 0 : 0);
}

function exp2ResetState() {
    exp2State.components = [];
    exp2State.connections = [];
    exp2State.pendingConnection = null;
    exp2State.truthResults = {
        halfAdder: {},
        fullAdder: {}
    };
    exp2State.completed = {
        halfAdder: false,
        fullAdder: false
    };
    exp2State.selectedCircuit = "halfAdder";
    const sumValue = document.getElementById("exp2SumValue");
    const carryValue = document.getElementById("exp2CarryValue");
    if (sumValue) sumValue.textContent = "—";
    if (carryValue) carryValue.textContent = "—";
}

function exp2ClearCurrentCircuit() {
    exp2State.components = [];
    exp2State.connections = [];
    exp2State.pendingConnection = null;
    const sumValue = document.getElementById("exp2SumValue");
    const carryValue = document.getElementById("exp2CarryValue");
    if (sumValue) sumValue.textContent = "—";
    if (carryValue) carryValue.textContent = "—";
}

function exp2InvalidateCurrentResults() {
    exp2State.truthResults[exp2State.selectedCircuit] = {};
    exp2State.completed[exp2State.selectedCircuit] = false;
    exp2State.components.forEach(function (component) {
        if (component.type === "SUM" || component.type === "CARRY") {
            component.value = null;
        }
    });
    const sumValue = document.getElementById("exp2SumValue");
    const carryValue = document.getElementById("exp2CarryValue");
    if (sumValue) sumValue.textContent = "—";
    if (carryValue) carryValue.textContent = "—";
}

function exp2GetInputComponents() {
    return {
        A: exp2State.components.find(function (component) { return component.type === "inputA"; }),
        B: exp2State.components.find(function (component) { return component.type === "inputB"; }),
        Cin: exp2State.components.find(function (component) { return component.type === "Cin"; })
    };
}

function exp2GetGateByType(type) {
    return exp2State.components.find(function (component) {
        return component.type === type;
    });
}

function exp2GetOutputComponent(type) {
    return exp2State.components.find(function (component) {
        return component.type === type;
    });
}

function exp2SetStatus(message, isError) {
    const statusBox = document.getElementById("exp2StatusBox");
    if (!statusBox) {
        return;
    }

    statusBox.dataset.fullStatus = message;
    statusBox.textContent = window.virtualDeldSettings
        ? window.virtualDeldSettings.formatStatus(message)
        : message;
    statusBox.classList.toggle("status-error", Boolean(isError));
}

function exp2UpdateCircuitButtons() {
    const buttons = document.querySelectorAll(".exp2-circuit-btn");
    buttons.forEach(function (button) {
        const isActive = button.dataset.circuit === exp2State.selectedCircuit;
        button.classList.toggle("active", isActive);
        button.disabled = false;
        button.setAttribute("aria-pressed", String(isActive));
    });

    const fullAdderSelected = exp2State.selectedCircuit === "fullAdder";
    const cinLibraryButton = document.querySelector('.exp2-library-item[data-library="Cin"]');
    const orLibraryButton = document.querySelector('.exp2-library-item[data-library="OR"]');
    const cinReadout = document.getElementById("exp2CinValue");
    const carryReadout = document.getElementById("exp2CarryValue");
    const truthTableHead = document.getElementById("exp2TruthTableHead");
    const guidedText = document.getElementById("exp2GuidedText");
    const modeTitle = document.getElementById("exp2ModeTitle");
    const runButton = document.getElementById("exp2RunSimulationBtn");
    const carryLibraryButton = document.querySelector('.exp2-library-item[data-library="CARRY"]');

    if (modeTitle) {
        modeTitle.textContent = fullAdderSelected ? "Full Adder" : "Half Adder";
    }
    if (runButton) {
        runButton.textContent = fullAdderSelected ? "RUN FULL ADDER" : "RUN HALF ADDER";
    }
    if (carryLibraryButton) {
        carryLibraryButton.textContent = fullAdderSelected ? "CARRY OUT" : "CARRY";
    }

    if (cinLibraryButton) {
        cinLibraryButton.hidden = !fullAdderSelected;
    }
    if (orLibraryButton) {
        orLibraryButton.hidden = !fullAdderSelected;
    }
    if (cinReadout) {
        const row = cinReadout.closest(".output-row");
        if (row) {
            row.hidden = !fullAdderSelected;
        }
    }
    if (carryReadout) {
        const label = carryReadout.previousElementSibling;
        if (label) {
            label.textContent = fullAdderSelected ? "CARRY OUT:" : "CARRY:";
        }
    }
    if (truthTableHead) {
        truthTableHead.innerHTML = fullAdderSelected
            ? "<tr><th>A</th><th>B</th><th>Cin</th><th>Expected Sum</th><th>Obtained Sum</th><th>Expected Carry Out</th><th>Obtained Carry Out</th><th>Status</th></tr>"
            : "<tr><th>A</th><th>B</th><th>Expected Sum</th><th>Obtained Sum</th><th>Expected Carry</th><th>Obtained Carry</th><th>Status</th></tr>";
    }
    if (guidedText) {
        guidedText.innerHTML = fullAdderSelected
            ? [
                "Step 1: Understand the Full Adder: it adds A, B, and Carry In to produce Sum and Carry Out.",
                "Step 2: Place Input A, Input B, and Carry In.",
                "Step 3: Place two XOR gates, two AND gates, one OR gate, and the Sum and Carry output indicators.",
                "Step 4: Connect A and B to the first XOR and AND gates; connect that XOR and Carry In to the second XOR and AND gates; connect both AND outputs to the OR gate.",
                "Step 5: Verify every input and output connection, then run Validate/Simulation.",
                "Step 6: Run the circuit for all eight A, B, and Carry In combinations.",
                "Step 7: Compare the obtained Sum and Carry Out with each truth-table row.",
                "Step 8: Full Adder progress completes only after all eight combinations have been simulated correctly."
            ].map(function (step) {
                const labelEnd = step.indexOf(":");
                return "<strong>" + step.slice(0, labelEnd + 1) + "</strong>" + step.slice(labelEnd + 1);
            }).join("<br>")
            : [
                "Step 1: Place Input A.",
                "Step 2: Place Input B.",
                "Step 3: Place an XOR gate for the SUM output.",
                "Step 4: Place an AND gate for the CARRY output.",
                "Step 5: Connect A and B to both gates.",
                "Step 6: Connect XOR output to SUM.",
                "Step 7: Connect AND output to CARRY."
            ].join("<br>");
    }
}

function exp2RenderProgress() {
    const node = document.getElementById("exp2ProgressStatus");
    if (!node) {
        return;
    }

    const halfState = exp2State.completed.halfAdder ? "✓" : "○";
    const fullState = exp2State.completed.fullAdder ? "✓" : "○";
    node.textContent = "Half Adder " + halfState + "   Full Adder " + fullState;

    const resultBox = document.getElementById("exp2ResultBox");
    if (resultBox) {
        if (exp2State.completed.halfAdder && exp2State.completed.fullAdder) {
            resultBox.innerHTML = "<strong>Experiment 02</strong>Half Adder: Circuit Completed<br>Truth Table: Verified<br><br>Full Adder: Circuit Completed<br>Truth Table: Verified<br><br>Overall Status: ✓ Experiment Completed";
        } else if (exp2State.completed.halfAdder || exp2State.completed.fullAdder) {
            resultBox.innerHTML = "<strong>Experiment 02</strong>Half Adder: " +
                (exp2State.completed.halfAdder ? "Circuit Completed<br>Truth Table: Verified" : "Not yet verified") +
                "<br><br>Full Adder: " +
                (exp2State.completed.fullAdder ? "Circuit Completed<br>Truth Table: Verified" : "Not yet verified");
        } else {
            resultBox.innerHTML = "<strong>Experiment 02</strong>Progress will appear here after simulation results are verified.";
        }
    }
}

function exp2GetTruthRows() {
    const mode = exp2State.selectedCircuit;
    return exp2TruthTables[mode].map(function (row) {
        const key = mode === "halfAdder" ? row.A + "-" + row.B : row.A + "-" + row.B + "-" + row.Cin;
        const result = exp2State.truthResults[mode][key] || {};
        return {
            ...row,
            obtainedSum: result.sum !== undefined ? result.sum : "-",
            obtainedCarry: result.carry !== undefined ? result.carry : "-",
            status: result.correct === undefined ? "-" : (result.correct ? "✓ Correct" : "✗ Incorrect")
        };
    });
}

function exp2RenderTruthTable() {
    const tbody = document.getElementById("exp2TruthTableBody");
    if (!tbody) {
        return;
    }

    const rows = exp2GetTruthRows();
    const mode = exp2State.selectedCircuit;

    if (mode === "halfAdder") {
        tbody.innerHTML = rows.map(function (row) {
            return "<tr><td>" + row.A + "</td><td>" + row.B + "</td><td>" + row.expectedSum + "</td><td>" + row.obtainedSum + "</td><td>" + row.expectedCarry + "</td><td>" + row.obtainedCarry + "</td><td>" + row.status + "</td></tr>";
        }).join("");
    } else {
        tbody.innerHTML = rows.map(function (row) {
            return "<tr><td>" + row.A + "</td><td>" + row.B + "</td><td>" + row.Cin + "</td><td>" + row.expectedSum + "</td><td>" + row.obtainedSum + "</td><td>" + row.expectedCarry + "</td><td>" + row.obtainedCarry + "</td><td>" + row.status + "</td></tr>";
        }).join("");
    }
}

function exp2CreateComponent(type, x, y) {
    exp2InvalidateCurrentResults();
    const component = {
        id: "exp2-comp-" + Date.now() + Math.random().toString(16).slice(2),
        type: type,
        x: x,
        y: y,
        value: type === "SUM" || type === "CARRY" ? null : 0,
        label: type === "inputA" ? "Input A" : type === "inputB" ? "Input B" : type === "Cin" ? "Carry In" : type === "SUM" ? "SUM" : type === "CARRY" ? (exp2State.selectedCircuit === "fullAdder" ? "CARRY OUT" : "CARRY") : type
    };

    exp2State.components.push(component);
    exp2RenderCircuitCanvas();
    exp2RenderTruthTable();
    exp2RenderProgress();
}

function exp2RemoveComponent(componentId) {
    exp2InvalidateCurrentResults();
    exp2State.components = exp2State.components.filter(function (component) {
        return component.id !== componentId;
    });

    exp2State.connections = exp2State.connections.filter(function (connection) {
        return connection.from !== componentId && connection.to !== componentId;
    });

    exp2RenderCircuitCanvas();
    exp2RenderTruthTable();
    exp2RenderProgress();
}

function exp2GetPinCoordinates(component, port) {
    const width = 110;
    const height = 52;
    const x = component.x;
    const y = component.y;

    if (port === "input1") {
        return { x: x + 6, y: y + height / 2 - 3 };
    }
    if (port === "input2") {
        return { x: x + 6, y: y + height / 2 + 18 };
    }
    if (port === "input") {
        return { x: x + 6, y: y + height / 2 };
    }
    return { x: x + width - 6, y: y + height / 2 };
}

function exp2RenderCircuitCanvas() {
    const canvas = document.getElementById("exp2CircuitCanvas");
    if (!canvas) {
        return;
    }

    canvas.innerHTML = "";

    const svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
    svg.setAttribute("viewBox", "0 0 " + (canvas.clientWidth || 800) + " " + (canvas.clientHeight || 520));
    svg.setAttribute("width", "100%");
    svg.setAttribute("height", "100%");

    exp2State.connections.forEach(function (connection) {
        const fromComponent = exp2GetComponentById(connection.from);
        const toComponent = exp2GetComponentById(connection.to);
        if (!fromComponent || !toComponent) {
            return;
        }

        const fromPoint = exp2GetPinCoordinates(fromComponent, "output");
        const toPoint = exp2GetPinCoordinates(toComponent, connection.toPort || "input");

        const line = document.createElementNS("http://www.w3.org/2000/svg", "path");
        line.setAttribute("d", "M " + fromPoint.x + " " + fromPoint.y + " C " + (fromPoint.x + 60) + " " + fromPoint.y + ", " + (toPoint.x - 60) + " " + toPoint.y + ", " + toPoint.x + " " + toPoint.y);
        line.setAttribute("fill", "none");
        line.setAttribute("stroke", "#4d7d58");
        line.setAttribute("stroke-width", "3");
        svg.appendChild(line);
    });

    canvas.appendChild(svg);

    exp2State.components.forEach(function (component) {
        const item = document.createElement("div");
        item.className = "circuit-component " + component.type;
        item.style.left = component.x + "px";
        item.style.top = component.y + "px";
        item.setAttribute("data-id", component.id);
        item.setAttribute("title", component.label);

        const label = document.createElement("div");
        label.className = "component-label";
        label.textContent = component.label;
        item.appendChild(label);

        if (component.type === "inputA" || component.type === "inputB" || component.type === "Cin") {
            const valueNode = document.createElement("div");
            valueNode.className = "component-value";
            valueNode.textContent = component.value === 1 ? "1" : "0";
            item.appendChild(valueNode);
        }

        if (component.type === "SUM" || component.type === "CARRY") {
            const valueNode = document.createElement("div");
            valueNode.className = "component-value output-value";
            valueNode.textContent = component.value === null ? "—" : component.value === 1 ? "1" : "0";
            item.appendChild(valueNode);
        }

        const pins = [];
        if (component.type === "AND" || component.type === "OR" || component.type === "XOR") {
            pins.push({ port: "input1", label: "1" });
            pins.push({ port: "input2", label: "2" });
            pins.push({ port: "output", label: "out" });
        } else if (component.type === "inputA" || component.type === "inputB" || component.type === "Cin") {
            pins.push({ port: "output", label: "out" });
        } else if (component.type === "SUM" || component.type === "CARRY") {
            pins.push({ port: "input", label: "in" });
        }

        pins.forEach(function (pinInfo) {
            const pin = document.createElement("button");
            pin.type = "button";
            pin.className = "pin " + pinInfo.port;
            pin.dataset.componentId = component.id;
            pin.dataset.port = pinInfo.port;
            pin.textContent = pinInfo.label;
            pin.addEventListener("click", function (event) {
                event.stopPropagation();
                exp2HandlePinClick(component.id, pinInfo.port);
            });
            item.appendChild(pin);
        });

        item.addEventListener("click", function () {
            if (component.type === "inputA" || component.type === "inputB" || component.type === "Cin") {
                component.value = component.value === 1 ? 0 : 1;
                exp2RenderCircuitCanvas();
                exp2RenderTruthTable();
                scheduleCombinationalAutoRun(exp2ValidateCircuit, exp2RunSimulation);
            }
        });

        item.addEventListener("dblclick", function () {
            exp2RemoveComponent(component.id);
        });

        item.addEventListener("mousedown", function (event) {
            if (event.target.tagName === "BUTTON") {
                return;
            }
            const dragState = {
                id: component.id,
                startX: event.clientX,
                startY: event.clientY,
                originX: component.x,
                originY: component.y
            };

            function onMouseMove(moveEvent) {
                const dx = moveEvent.clientX - dragState.startX;
                const dy = moveEvent.clientY - dragState.startY;
                const canvas = document.getElementById("exp2CircuitCanvas");
                const target = exp2GetComponentById(dragState.id);
                if (target) {
                    target.x = Math.max(10, Math.min((canvas ? canvas.clientWidth : 800) - 120, dragState.originX + dx));
                    target.y = Math.max(10, Math.min((canvas ? canvas.clientHeight : 520) - 60, dragState.originY + dy));
                    exp2RenderCircuitCanvas();
                }
            }

            function onMouseUp() {
                window.removeEventListener("mousemove", onMouseMove);
                window.removeEventListener("mouseup", onMouseUp);
            }

            window.addEventListener("mousemove", onMouseMove);
            window.addEventListener("mouseup", onMouseUp);
        });

        canvas.appendChild(item);
    });
}

function exp2HandlePinClick(componentId, port) {
    const component = exp2GetComponentById(componentId);
    if (!component) {
        return;
    }

    if (!exp2State.pendingConnection) {
        const sourcePortIsOutput = port === "output";
        if (!sourcePortIsOutput) {
            exp2SetStatus("Start a wire from an output terminal.", true);
            return;
        }
        exp2State.pendingConnection = { from: componentId, fromPort: port };
        exp2SetStatus("Select a destination input to complete the connection.", false);
        return;
    }

    if (exp2State.pendingConnection.from === componentId) {
        exp2State.pendingConnection = null;
        setCircuitValidationError(exp2SetStatus, { message: "Invalid Connection\nA component cannot connect to itself." });
        return;
    }

    const fromComponent = exp2GetComponentById(exp2State.pendingConnection.from);
    const targetComponent = component;
    if (!fromComponent || !targetComponent) {
        exp2State.pendingConnection = null;
        return;
    }

    const invalid = exp2ValidateConnection(fromComponent, exp2State.pendingConnection.fromPort, targetComponent, port);
    if (!invalid.valid) {
        setCircuitValidationError(exp2SetStatus, invalid);
        exp2State.pendingConnection = null;
        return;
    }

    const occupied = exp2State.connections.some(function (connection) {
        return connection.to === targetComponent.id && connection.toPort === port;
    });
    if (occupied) {
        exp2SetStatus("Multiple drivers are not allowed on one input terminal.", true);
        exp2State.pendingConnection = null;
        return;
    }
    if (hasCircuitCycle(exp2State.components, exp2State.connections.concat([{
        from: fromComponent.id,
        to: targetComponent.id
    }]))) {
        exp2SetStatus("Circular dependency detected. Check the circuit connections.", true);
        exp2State.pendingConnection = null;
        return;
    }

    exp2State.connections.push({
        from: fromComponent.id,
        fromPort: exp2State.pendingConnection.fromPort,
        to: targetComponent.id,
        toPort: port
    });
    exp2InvalidateCurrentResults();
    exp2SetStatus("Connection successful.", false);
    exp2State.pendingConnection = null;
    exp2RenderCircuitCanvas();
}

function exp2ValidateConnection(fromComponent, fromPort, toComponent, toPort) {
    if (fromPort !== "output") {
        return { valid: false, message: "Invalid Connection. Start from an output terminal." };
    }
    const validTargetPort = ["XOR", "AND", "OR"].includes(toComponent.type)
        ? ["input1", "input2"].includes(toPort)
        : ["SUM", "CARRY"].includes(toComponent.type) && toPort === "input";
    if (!validTargetPort) {
        return { valid: false, message: "Invalid Connection. Connect an output terminal to a compatible input." };
    }

    if (fromComponent.type === "SUM" || fromComponent.type === "CARRY") {
        return { valid: false, message: "Invalid Connection\nSUM or CARRY cannot be used as a source.", };
    }

    if (toComponent.type === "SUM" || toComponent.type === "CARRY") {
        if (fromComponent.type === "XOR" || fromComponent.type === "AND" || fromComponent.type === "OR") {
            return { valid: true, message: "Connection successful." };
        }
    }

    if (fromComponent.type === "inputA" || fromComponent.type === "inputB" || fromComponent.type === "Cin") {
        if (toComponent.type === "inputA" || toComponent.type === "inputB" || toComponent.type === "Cin") {
            return { valid: false, message: "Invalid Connection\nAn input cannot connect to another input." };
        }
        if (toComponent.type === "XOR" || toComponent.type === "AND" || toComponent.type === "OR") {
            return { valid: true, message: "Connection successful." };
        }
    }

    if ((fromComponent.type === "XOR" || fromComponent.type === "AND" || fromComponent.type === "OR") && toComponent.type === "SUM") {
        return { valid: true, message: "Connection successful." };
    }

    if ((fromComponent.type === "XOR" || fromComponent.type === "AND" || fromComponent.type === "OR") && toComponent.type === "CARRY") {
        return { valid: true, message: "Connection successful." };
    }

    if (
        (fromComponent.type === "XOR" || fromComponent.type === "AND" || fromComponent.type === "OR") &&
        (toComponent.type === "XOR" || toComponent.type === "AND" || toComponent.type === "OR")
    ) {
        return { valid: true, message: "Connection successful." };
    }

    return { valid: false, message: "Invalid Connection\nThis connection is not allowed in the current circuit." };
}

function exp2EvaluateNode(nodeId, visited) {
    const path = new Set(visited || []);
    if (path.has(nodeId)) {
        return null;
    }
    path.add(nodeId);

    const component = exp2GetComponentById(nodeId);
    if (!component) {
        return null;
    }

    if (component.type === "inputA" || component.type === "inputB" || component.type === "Cin") {
        return Number(component.value);
    }

    if (component.type === "SUM" || component.type === "CARRY") {
        const incoming = exp2State.connections.filter(function (connection) {
            return connection.to === component.id && connection.toPort === "input";
        });
        if (incoming.length !== 1) {
            return null;
        }
        const source = exp2GetComponentById(incoming[0].from);
        if (!source) {
            return null;
        }
        return exp2EvaluateNode(source.id, path);
    }

    if (component.type === "AND" || component.type === "OR" || component.type === "XOR") {
        const incoming = exp2State.connections.filter(function (connection) {
            return connection.to === component.id;
        });
        const ports = ["input1", "input2"];
        const values = ports.map(function (port) {
            const connection = incoming.find(function (item) {
                return item.toPort === port;
            });
            const source = connection && exp2GetComponentById(connection.from);
            return source ? exp2EvaluateNode(source.id, path) : null;
        });
        if (incoming.length !== 2 || values.some(function (value) { return value !== 0 && value !== 1; })) {
            return null;
        }

        if (component.type === "AND") {
            return gateLogic.AND(values[0], values[1]);
        }
        if (component.type === "OR") {
            return gateLogic.OR(values[0], values[1]);
        }
        return gateLogic.XOR(values[0], values[1]);
    }

    return null;
}

function exp2ValidateCircuit() {
    const mode = exp2State.selectedCircuit;
    if (hasCircuitCycle(exp2State.components, exp2State.connections)) {
        return { valid: false, message: "Circular dependency detected. Check the circuit connections." };
    }

    const drivenInputs = new Set();
    for (let index = 0; index < exp2State.connections.length; index += 1) {
        const connection = exp2State.connections[index];
        const key = connection.to + ":" + connection.toPort;
        if (drivenInputs.has(key)) {
            return { valid: false, message: "Multiple drivers are connected to one input." };
        }
        drivenInputs.add(key);
    }

    if (mode === "halfAdder") {
        const inputA = exp2State.components.find(function (item) { return item.type === "inputA"; });
        const inputB = exp2State.components.find(function (item) { return item.type === "inputB"; });
        const xorGate = exp2State.components.find(function (item) { return item.type === "XOR"; });
        const andGate = exp2State.components.find(function (item) { return item.type === "AND"; });
        const sumOutput = exp2State.components.find(function (item) { return item.type === "SUM"; });
        const carryOutput = exp2State.components.find(function (item) { return item.type === "CARRY"; });

        if (!inputA || !inputB) {
            return { valid: false, message: "⚠ Incomplete Circuit\nHalf Adder:\nInput A or Input B is missing." };
        }
        if (!xorGate || !andGate) {
            return { valid: false, message: "⚠ Missing Gate\nHalf Adder needs an XOR gate and an AND gate." };
        }
        if (!sumOutput) {
            return { valid: false, message: "⚠ Output Not Connected\nThe SUM output is not connected.\nConnect XOR output to SUM." };
        }
        if (!carryOutput) {
            return { valid: false, message: "⚠ Output Not Connected\nThe CARRY output is not connected.\nConnect AND output to CARRY." };
        }

        if (!exp2GateHasInputs(xorGate, [inputA.id, inputB.id])) {
            return { valid: false, message: "⚠ Incomplete Circuit\nHalf Adder:\nBoth A and B must be connected to the XOR gate." };
        }
        if (!exp2GateHasInputs(andGate, [inputA.id, inputB.id])) {
            return { valid: false, message: "⚠ Incomplete Circuit\nHalf Adder:\nBoth A and B must be connected to the AND gate." };
        }
        if (!exp2HasConnection(xorGate, sumOutput, "input")) {
            return { valid: false, message: "⚠ Output Not Connected\nThe XOR output is not connected to SUM." };
        }
        if (!exp2HasConnection(andGate, carryOutput, "input")) {
            return { valid: false, message: "⚠ Output Not Connected\nThe AND output is not connected to CARRY." };
        }

        return { valid: true, message: "Circuit valid." };
    }

    const inputA = exp2State.components.find(function (item) { return item.type === "inputA"; });
    const inputB = exp2State.components.find(function (item) { return item.type === "inputB"; });
    const cin = exp2State.components.find(function (item) { return item.type === "Cin"; });
    const xorGates = exp2State.components.filter(function (item) { return item.type === "XOR"; });
    const andGates = exp2State.components.filter(function (item) { return item.type === "AND"; });
    const orGates = exp2State.components.filter(function (item) { return item.type === "OR"; });
    const sumOutput = exp2State.components.find(function (item) { return item.type === "SUM"; });
    const carryOutput = exp2State.components.find(function (item) { return item.type === "CARRY"; });

    if (!inputA || !inputB || !cin) {
        return { valid: false, message: "⚠ Incomplete Circuit\nFull Adder needs Input A, Input B, and Carry In." };
    }
    if (xorGates.length < 2 || andGates.length < 2 || orGates.length < 1) {
        return { valid: false, message: "⚠ Missing Gate\nFull Adder needs two XOR gates, two AND gates, and one OR gate." };
    }
    if (!sumOutput || !carryOutput) {
        return { valid: false, message: "⚠ Output Not Connected\nConnect the final output to SUM and CARRY." };
    }

    let topologyValid = false;
    xorGates.forEach(function (xorAB) {
        if (!exp2GateHasInputs(xorAB, [inputA.id, inputB.id])) {
            return;
        }
        xorGates.forEach(function (xorSum) {
            if (xorSum.id === xorAB.id ||
                !exp2GateHasInputs(xorSum, [xorAB.id, cin.id]) ||
                !exp2HasConnection(xorSum, sumOutput, "input")) {
                return;
            }
            andGates.forEach(function (andAB) {
                if (!exp2GateHasInputs(andAB, [inputA.id, inputB.id])) {
                    return;
                }
                andGates.forEach(function (andCarry) {
                    if (andCarry.id === andAB.id ||
                        !exp2GateHasInputs(andCarry, [xorAB.id, cin.id])) {
                        return;
                    }
                    orGates.forEach(function (orCarry) {
                        if (exp2GateHasInputs(orCarry, [andAB.id, andCarry.id]) &&
                            exp2HasConnection(orCarry, carryOutput, "input")) {
                            topologyValid = true;
                        }
                    });
                });
            });
        });
    });

    if (!topologyValid) {
        return { valid: false, message: "⚠ Incomplete Circuit\nBuild the full-adder network: A and B into XOR and AND, XOR with Cin into the second XOR and AND, then both AND outputs into OR." };
    }

    return { valid: true, message: "Circuit valid." };
}

function exp2UpdateTruthResult(mode, key, sumValue, carryValue) {
    const expectedRows = exp2TruthTables[mode];
    const row = expectedRows.find(function (item) {
        if (mode === "halfAdder") {
            return item.A + "-" + item.B === key;
        }
        return item.A + "-" + item.B + "-" + item.Cin === key;
    });

    if (!row) {
        return;
    }

    const correct = Number(sumValue) === Number(row.expectedSum) && Number(carryValue) === Number(row.expectedCarry);
    exp2State.truthResults[mode][key] = {
        sum: Number(sumValue),
        carry: Number(carryValue),
        correct: correct
    };

    const allRowsCorrect = exp2TruthTables[mode].every(function (item) {
        const rowKey = mode === "halfAdder" ? item.A + "-" + item.B : item.A + "-" + item.B + "-" + item.Cin;
        const result = exp2State.truthResults[mode][rowKey];
        return result && result.correct;
    });

    exp2State.completed[mode] = allRowsCorrect;
}

function exp2RunSimulation() {
    const validation = exp2ValidateCircuit();
    if (!validation.valid) {
        setCircuitValidationError(exp2SetStatus, validation);
        return;
    }

    const mode = exp2State.selectedCircuit;
    const rowData = exp2TruthTables[mode];
    if (!rowData) {
        return;
    }

    let sumValue = 0;
    let carryValue = 0;
    let currentKey = "";

    if (mode === "halfAdder") {
        const a = Number(exp2GetInputValue("inputA"));
        const b = Number(exp2GetInputValue("inputB"));
        const sumOutput = exp2State.components.find(function (item) { return item.type === "SUM"; });
        const carryOutput = exp2State.components.find(function (item) { return item.type === "CARRY"; });

        sumValue = sumOutput ? exp2EvaluateNode(sumOutput.id) : 0;
        carryValue = carryOutput ? exp2EvaluateNode(carryOutput.id) : 0;
        if (sumOutput) {
            sumOutput.value = sumValue;
        }
        if (carryOutput) {
            carryOutput.value = carryValue;
        }
        currentKey = a + "-" + b;
    } else {
        const a = Number(exp2GetInputValue("inputA"));
        const b = Number(exp2GetInputValue("inputB"));
        const cin = Number(exp2GetInputValue("Cin"));
        const sumOutput = exp2State.components.find(function (item) { return item.type === "SUM"; });
        const carryOutput = exp2State.components.find(function (item) { return item.type === "CARRY"; });
        sumValue = sumOutput ? exp2EvaluateNode(sumOutput.id) : 0;
        carryValue = carryOutput ? exp2EvaluateNode(carryOutput.id) : 0;
        if (sumOutput) sumOutput.value = sumValue;
        if (carryOutput) carryOutput.value = carryValue;
        currentKey = a + "-" + b + "-" + cin;
    }

    if (![0, 1].includes(sumValue) || ![0, 1].includes(carryValue)) {
        exp2SetStatus("Circuit produced an undefined signal. Check every gate input and connection before simulation.", true);
        return;
    }

    const sumNode = document.getElementById("exp2SumValue");
    const carryNode = document.getElementById("exp2CarryValue");
    if (sumNode) sumNode.textContent = String(sumValue);
    if (carryNode) carryNode.textContent = String(carryValue);

    const truthVerificationEnabled = getVirtualLabSettings().truthTableVerification;
    if (truthVerificationEnabled) {
        exp2UpdateTruthResult(mode, currentKey, sumValue, carryValue);
    }
    const verification = truthVerificationEnabled ? exp2State.truthResults[mode][currentKey] : null;
    exp2RenderTruthTable();
    exp2RenderProgress();
    exp2UpdateCircuitButtons();
    exp2RenderCircuitCanvas();

    if (!getVirtualLabSettings().showOutputValues) {
        exp2SetStatus(
            truthVerificationEnabled
                ? (verification && verification.correct ? "✓ Correct Output." : "✗ Output mismatch.")
                : "Simulation complete.",
            truthVerificationEnabled && !(verification && verification.correct)
        );
    } else if (!truthVerificationEnabled) {
        exp2SetStatus("Simulation complete.\nSUM: " + sumValue + "\nCARRY: " + carryValue, false);
    } else {
        exp2SetStatus(
            (verification && verification.correct ? "✓ Correct Output" : "✗ Output mismatch") +
            "\nSUM: " + sumValue + "\nCARRY: " + carryValue,
            !(verification && verification.correct)
        );
    }
}

function exp2OpenWorkspace() {
    const detail = document.querySelector(".experiment-detail-panel");
    const workspace = document.getElementById("exp02Workspace");
    if (detail) detail.style.display = "none";
    if (workspace) workspace.classList.remove("hidden");
}

function exp2CloseWorkspace() {
    const detail = document.querySelector(".experiment-detail-panel");
    const workspace = document.getElementById("exp02Workspace");
    if (detail) detail.style.display = "block";
    if (workspace) workspace.classList.add("hidden");
}

function exp2AttachEvents() {
    const startButton = document.getElementById("startExp2Btn");
    const backButton = document.getElementById("backToExp2Btn");
    const runButton = document.getElementById("exp2RunSimulationBtn");
    const resetButton = document.getElementById("exp2ResetBtn");
    const circuitButtons = document.querySelectorAll(".exp2-circuit-btn");
    const libraryButtons = document.querySelectorAll(".exp2-library-item");

    if (startButton) {
        startButton.addEventListener("click", function () {
            exp2ResetState();
            exp2OpenWorkspace();
            exp2RenderTruthTable();
            exp2RenderProgress();
            exp2UpdateCircuitButtons();
        });
    }

    if (backButton) {
        backButton.addEventListener("click", function () {
            exp2CloseWorkspace();
        });
    }

    if (runButton) {
        runButton.addEventListener("click", exp2RunSimulation);
    }

    if (resetButton) {
        resetButton.addEventListener("click", function () {
            exp2ResetState();
            exp2RenderCircuitCanvas();
            exp2RenderTruthTable();
            exp2RenderProgress();
            exp2UpdateCircuitButtons();
            exp2SetStatus("Ready for simulation.", false);
        });
    }

    circuitButtons.forEach(function (button) {
        button.addEventListener("click", function () {
            const mode = button.dataset.circuit;
            if (mode !== "halfAdder" && mode !== "fullAdder") {
                return;
            }
            if (mode === exp2State.selectedCircuit) {
                return;
            }
            exp2State.selectedCircuit = mode;
            exp2ClearCurrentCircuit();
            exp2RenderTruthTable();
            exp2RenderProgress();
            exp2UpdateCircuitButtons();
            exp2RenderCircuitCanvas();
            exp2SetStatus("Selected circuit: " + (mode === "halfAdder" ? "Half Adder" : "Full Adder") + ".", false);
        });
    });

    libraryButtons.forEach(function (button) {
        button.addEventListener("click", function () {
            const type = button.dataset.library;
            const canvas = document.getElementById("exp2CircuitCanvas");
            const canvasWidth = canvas ? canvas.clientWidth : 800;
            const outputX = Math.max(10, canvasWidth - 120);
            let position;

            if (exp2State.selectedCircuit === "fullAdder") {
                const firstStageX = Math.max(120, Math.round(canvasWidth * 0.27));
                const secondStageX = Math.max(firstStageX + 120, outputX - 135);
                const duplicateIndex = exp2State.components.filter(function (component) {
                    return component.type === type;
                }).length;
                const fullAdderPositions = {
                    inputA: { x: 10, y: 70 },
                    inputB: { x: 10, y: 210 },
                    Cin: { x: 10, y: 350 },
                    XOR: { x: duplicateIndex === 0 ? firstStageX : secondStageX, y: duplicateIndex === 0 ? 90 : 55 },
                    AND: { x: duplicateIndex === 0 ? firstStageX : secondStageX, y: duplicateIndex === 0 ? 290 : 245 },
                    OR: { x: secondStageX, y: 365 },
                    SUM: { x: outputX, y: 70 },
                    CARRY: { x: outputX, y: 365 }
                };
                position = fullAdderPositions[type];
            } else {
                const gateX = Math.max(150, Math.round(canvasWidth * 0.42));
                const halfAdderPositions = {
                    inputA: { x: 20, y: 120 },
                    inputB: { x: 20, y: 250 },
                    XOR: { x: gateX, y: 120 },
                    AND: { x: gateX, y: 270 },
                    SUM: { x: outputX, y: 120 },
                    CARRY: { x: outputX, y: 270 }
                };
                position = halfAdderPositions[type];
            }

            if (position) {
                exp2CreateComponent(type, position.x, position.y);
            }
        });
    });
}

document.addEventListener("DOMContentLoaded", function () {
    const detailPanel = document.getElementById("experimentDetailPanel");
    if (detailPanel) {
        detailPanel.style.display = "block";
    }

    attachExperimentOneEvents();
    exp2AttachEvents();
    exp3AttachEvents();
    updateGateButtons();
    renderTruthTable();
    renderProgress();
    renderCircuitCanvas();
    exp2RenderTruthTable();
    exp2RenderProgress();
    exp2UpdateCircuitButtons();
    exp3RenderCanvas();
    exp3RenderTruthTable();
    exp3UpdateSimulationPanel();
    exp3RenderProgress();
    setStatus("Ready for simulation.", false);
});