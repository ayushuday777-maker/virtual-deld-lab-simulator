(function () {
    const form = document.getElementById("loginForm");
    const emailInput = document.getElementById("email");
    const passwordInput = document.getElementById("password");
    const emailError = document.getElementById("emailError");
    const passwordError = document.getElementById("passwordError");
    const formMessage = document.getElementById("formMessage");
    const loginButton = document.getElementById("loginButton");
    const togglePasswordButton = document.getElementById("togglePassword");
    const forgotPasswordButton = document.getElementById("forgotPassword");
    const googleButton = document.getElementById("googleButton");

    function setFieldError(input, errorElement, message) {
        errorElement.textContent = message;
        input.setAttribute("aria-invalid", String(Boolean(message)));
    }

    function clearFormMessage() {
        formMessage.textContent = "";
        formMessage.removeAttribute("data-kind");
    }

    function showFormMessage(message, kind) {
        formMessage.textContent = message;
        formMessage.dataset.kind = kind;
    }

    function validateEmail() {
        const email = emailInput.value.trim();
        emailInput.value = email;

        if (!email) {
            setFieldError(emailInput, emailError, "Please enter your email address.");
            return false;
        }
        if (!emailInput.validity.valid) {
            setFieldError(emailInput, emailError, "Please enter a valid email address.");
            return false;
        }

        setFieldError(emailInput, emailError, "");
        return true;
    }

    function validatePassword() {
        if (!passwordInput.value) {
            setFieldError(passwordInput, passwordError, "Please enter your password.");
            return false;
        }

        setFieldError(passwordInput, passwordError, "");
        return true;
    }

    form.addEventListener("submit", function (event) {
        event.preventDefault();
        clearFormMessage();

        const emailIsValid = validateEmail();
        const passwordIsValid = validatePassword();
        if (!emailIsValid || !passwordIsValid) {
            (emailIsValid ? passwordInput : emailInput).focus();
            return;
        }

        loginButton.disabled = true;
        loginButton.textContent = "Signing in...";
        showFormMessage(
            "Demo login successful. No account was authenticated. Returning to the Dashboard...",
            "success"
        );
        window.setTimeout(function () {
            window.location.assign("index.html");
        }, 700);
    });

    togglePasswordButton.addEventListener("click", function () {
        const showPassword = passwordInput.type === "password";
        passwordInput.type = showPassword ? "text" : "password";
        togglePasswordButton.textContent = showPassword ? "Hide" : "Show";
        togglePasswordButton.setAttribute("aria-pressed", String(showPassword));
        togglePasswordButton.setAttribute(
            "aria-label",
            showPassword ? "Hide password" : "Show password"
        );
        passwordInput.focus();
    });

    forgotPasswordButton.addEventListener("click", function () {
        clearFormMessage();
        if (!validateEmail()) {
            emailInput.focus();
            return;
        }

        showFormMessage(
            "Password reset is not configured in this frontend demo. No reset email was sent.",
            "info"
        );
    });

    googleButton.addEventListener("click", function () {
        clearFormMessage();
        showFormMessage(
            "Google sign-in is not configured for this demo. No Google account information was requested.",
            "info"
        );
    });

    emailInput.addEventListener("input", function () {
        if (emailInput.getAttribute("aria-invalid") === "true") {
            validateEmail();
        }
        clearFormMessage();
    });

    passwordInput.addEventListener("input", function () {
        if (passwordInput.getAttribute("aria-invalid") === "true") {
            validatePassword();
        }
        clearFormMessage();
    });
})();
