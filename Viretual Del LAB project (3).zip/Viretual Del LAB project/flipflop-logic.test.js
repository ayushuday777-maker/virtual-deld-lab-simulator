const assert = require('assert');
const flipFlopLogic = require('./flipflop-logic.js');

assert.deepStrictEqual(flipFlopLogic.srNextState(1, 1, 0), {
  nextQ: 0,
  valid: false,
  operation: 'Invalid',
  message: 'Invalid SR Input\nS and R cannot both be HIGH in this implementation.'
});

assert.strictEqual(flipFlopLogic.jkNextState(1, 1, 0).nextQ, 1);
assert.strictEqual(flipFlopLogic.jkNextState(1, 1, 1).nextQ, 0);
assert.strictEqual(flipFlopLogic.dNextState(1).nextQ, 1);
assert.strictEqual(flipFlopLogic.tNextState(1, 1).nextQ, 0);
assert.strictEqual(flipFlopLogic.clockEdgeDetected(0, 1), true);
assert.strictEqual(flipFlopLogic.clockEdgeDetected(1, 1), false);

console.log('Flip-flop logic tests passed.');
