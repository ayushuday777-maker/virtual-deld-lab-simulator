(function (globalScope) {
    function normalizeLogicValue(value) {
        if (value === null || value === undefined) {
            return null;
        }

        if (value === true || value === '1' || value === 1) {
            return 1;
        }

        if (value === false || value === '0' || value === 0) {
            return 0;
        }

        return Number(value) === 1 ? 1 : 0;
    }

    function complementOutput(value) {
        const normalized = normalizeLogicValue(value);
        if (normalized === null) {
            return null;
        }
        return normalized === 1 ? 0 : 1;
    }

    function srNextState(s, r, previousQ) {
        const set = normalizeLogicValue(s);
        const reset = normalizeLogicValue(r);
        const prev = normalizeLogicValue(previousQ);

        if (set === 1 && reset === 1) {
            return {
                nextQ: prev === null ? 0 : prev,
                valid: false,
                operation: 'Invalid',
                message: 'Invalid SR Input\nS and R cannot both be HIGH in this implementation.'
            };
        }

        if (reset === 1) {
            return { nextQ: 0, valid: true, operation: 'Reset' };
        }

        if (set === 1) {
            return { nextQ: 1, valid: true, operation: 'Set' };
        }

        return { nextQ: prev === null ? 0 : prev, valid: true, operation: 'Hold' };
    }

    function jkNextState(j, k, previousQ) {
        const set = normalizeLogicValue(j);
        const reset = normalizeLogicValue(k);
        const prev = normalizeLogicValue(previousQ);

        if (set === 0 && reset === 0) {
            return { nextQ: prev === null ? 0 : prev, valid: true, operation: 'Hold' };
        }

        if (set === 0 && reset === 1) {
            return { nextQ: 0, valid: true, operation: 'Reset' };
        }

        if (set === 1 && reset === 0) {
            return { nextQ: 1, valid: true, operation: 'Set' };
        }

        return {
            nextQ: prev === null ? 1 : (prev === 1 ? 0 : 1),
            valid: true,
            operation: 'Toggle'
        };
    }

    function dNextState(d) {
        const value = normalizeLogicValue(d);
        return {
            nextQ: value === null ? 0 : value,
            valid: true,
            operation: value === 1 ? 'Set to 1' : 'Reset to 0'
        };
    }

    function tNextState(t, previousQ) {
        const toggle = normalizeLogicValue(t);
        const prev = normalizeLogicValue(previousQ);
        const next = toggle === 1 ? (prev === 1 ? 0 : 1) : (prev === null ? 0 : prev);

        return {
            nextQ: next,
            valid: true,
            operation: toggle === 1 ? 'Toggle' : 'Hold'
        };
    }

    function clockEdgeDetected(previousClock, currentClock) {
        return normalizeLogicValue(previousClock) === 0 && normalizeLogicValue(currentClock) === 1;
    }

    function resetFlipFlopState(initialValue) {
        const startValue = normalizeLogicValue(initialValue) === null ? 0 : normalizeLogicValue(initialValue);
        return {
            currentQ: startValue,
            previousQ: null,
            qBar: complementOutput(startValue),
            clockState: 0,
            status: 'Reset complete'
        };
    }

    const api = {
        normalizeLogicValue,
        complementOutput,
        srNextState,
        jkNextState,
        dNextState,
        tNextState,
        clockEdgeDetected,
        resetFlipFlopState
    };

    if (typeof module !== 'undefined' && module.exports) {
        module.exports = api;
    }

    globalScope.flipFlopLogic = api;
})(typeof window !== 'undefined' ? window : globalThis);
