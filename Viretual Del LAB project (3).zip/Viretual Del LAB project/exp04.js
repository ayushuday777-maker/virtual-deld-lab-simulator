(function () {
    const state = {
        components: [],
        connections: [],
        pendingConnection: null,
        pulseCount: 0,
        initialized: false,
        results: {}
    };
    const sequence = Array.from({ length: 9 }, function (_, pulse) {
        return { pulse: pulse, value: pulse % 8 };
    });

    function setting(name, fallback) {
        return window.virtualDeldSettings
            ? window.virtualDeldSettings.get()[name]
            : fallback;
    }

    function setStatus(message, isError) {
        const box = document.getElementById("exp4StatusBox");
        if (!box) {
            return;
        }
        box.dataset.fullStatus = message;
        box.textContent = window.virtualDeldSettings
            ? window.virtualDeldSettings.formatStatus(message)
            : message;
        box.classList.toggle("status-error", Boolean(isError));
    }

    function findComponent(id) {
        return state.components.find(function (component) {
            return component.id === id;
        });
    }

    function outputBits(value) {
        return {
            Q2: (value >> 2) & 1,
            Q1: (value >> 1) & 1,
            Q0: value & 1
        };
    }

    function createComponent(type) {
        const canvas = document.getElementById("exp04CircuitCanvas");
        const indicatorX = Math.max(180, (canvas ? canvas.clientWidth : 800) - 125);
        const counterX = Math.max(75, Math.min(indicatorX - 185, Math.round(indicatorX * 0.48)));
        const positions = {
            CLK: { x: 45, y: 100 },
            COUNTER: { x: counterX, y: 200 },
            Q2: { x: indicatorX, y: 125 },
            Q1: { x: indicatorX, y: 220 },
            Q0: { x: indicatorX, y: 315 }
        };
        const labels = {
            CLK: "Clock Input",
            COUNTER: "3-bit Synchronous Counter",
            Q2: "Q2 Indicator",
            Q1: "Q1 Indicator",
            Q0: "Q0 Indicator"
        };
        const component = {
            id: "exp4-" + type + "-" + Date.now() + Math.random().toString(16).slice(2),
            type: type,
            label: labels[type],
            x: positions[type].x,
            y: positions[type].y
        };
        state.components.push(component);
        renderCanvas();
        updateReadout();
    }

    function removeComponent(id) {
        state.components = state.components.filter(function (component) {
            return component.id !== id;
        });
        state.connections = state.connections.filter(function (connection) {
            return connection.from !== id && connection.to !== id;
        });
        renderCanvas();
        updateReadout();
    }

    function getPins(type) {
        if (type === "CLK") {
            return [{ port: "output", label: "CLK" }];
        }
        if (type === "COUNTER") {
            return [
                { port: "CLK", label: "CLK" },
                { port: "Q2", label: "Q2" },
                { port: "Q1", label: "Q1" },
                { port: "Q0", label: "Q0" }
            ];
        }
        return [{ port: "input", label: "in" }];
    }

    function getPinPoint(component, port) {
        const canvas = document.getElementById("exp04CircuitCanvas");
        const element = canvas.querySelector('[data-id="' + component.id + '"]');
        const pin = element && element.querySelector('[data-port="' + port + '"]');
        if (!pin) {
            return { x: component.x, y: component.y };
        }
        const canvasRect = canvas.getBoundingClientRect();
        const pinRect = pin.getBoundingClientRect();
        return {
            x: pinRect.left - canvasRect.left + pinRect.width / 2,
            y: pinRect.top - canvasRect.top + pinRect.height / 2
        };
    }

    function renderCanvas() {
        const canvas = document.getElementById("exp04CircuitCanvas");
        if (!canvas) {
            return;
        }

        canvas.innerHTML = "";
        const svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
        svg.setAttribute("viewBox", "0 0 " + canvas.clientWidth + " " + canvas.clientHeight);
        svg.setAttribute("width", "100%");
        svg.setAttribute("height", "100%");
        svg.style.position = "absolute";
        svg.style.inset = "0";
        svg.style.pointerEvents = "none";
        svg.style.zIndex = "1";
        canvas.appendChild(svg);

        state.components.forEach(function (component) {
            const node = document.createElement("div");
            node.className = "circuit-component exp4-component " + component.type;
            node.style.left = component.x + "px";
            node.style.top = component.y + "px";
            node.dataset.id = component.id;
            node.title = component.label + " (double-click to remove)";

            const label = document.createElement("div");
            label.className = "component-label";
            label.textContent = component.label;
            node.appendChild(label);

            if (component.type === "COUNTER") {
                const bits = outputBits(state.pulseCount % 8);
                const value = document.createElement("div");
                value.className = "component-value output-value";
                value.textContent = bits.Q2 + " " + bits.Q1 + " " + bits.Q0;
                node.appendChild(value);
            } else if (component.type === "CLK") {
                const value = document.createElement("div");
                value.className = "component-value";
                value.textContent = "Manual";
                node.appendChild(value);
            } else {
                const bits = outputBits(state.pulseCount % 8);
                const value = document.createElement("div");
                value.className = "component-value output-value";
                value.textContent = state.initialized ? String(bits[component.type]) : "—";
                node.appendChild(value);
            }

            getPins(component.type).forEach(function (pinInfo) {
                const pin = document.createElement("button");
                pin.type = "button";
                pin.className = "pin exp4-pin " + pinInfo.port;
                pin.dataset.port = pinInfo.port;
                pin.setAttribute("aria-label", component.label + " " + pinInfo.label + " terminal");
                pin.textContent = pinInfo.label;
                positionPin(pin, component.type, pinInfo.port);
                pin.addEventListener("click", function (event) {
                    event.stopPropagation();
                    handlePinClick(component.id, pinInfo.port);
                });
                node.appendChild(pin);
            });

            node.addEventListener("click", function () {
                if (component.type === "CLK") {
                    setStatus("Use Apply Clock Pulse to generate a manual rising edge.", false);
                }
            });
            node.addEventListener("dblclick", function (event) {
                event.stopPropagation();
                removeComponent(component.id);
            });
            node.addEventListener("mousedown", function (event) {
                if (event.target.closest(".pin") || event.target.closest(".component-value")) {
                    return;
                }
                event.preventDefault();
                const origin = { x: component.x, y: component.y, mouseX: event.clientX, mouseY: event.clientY };
                function move(moveEvent) {
                    component.x = Math.max(8, Math.min(canvas.clientWidth - 125, origin.x + moveEvent.clientX - origin.mouseX));
                    component.y = Math.max(8, Math.min(canvas.clientHeight - 70, origin.y + moveEvent.clientY - origin.mouseY));
                    renderCanvas();
                }
                function stop() {
                    window.removeEventListener("mousemove", move);
                    window.removeEventListener("mouseup", stop);
                }
                window.addEventListener("mousemove", move);
                window.addEventListener("mouseup", stop);
            });
            canvas.appendChild(node);
        });

        state.connections.forEach(function (connection) {
            const source = findComponent(connection.from);
            const target = findComponent(connection.to);
            if (!source || !target) {
                return;
            }
            const from = getPinPoint(source, connection.fromPort);
            const to = getPinPoint(target, connection.toPort);
            const path = document.createElementNS("http://www.w3.org/2000/svg", "path");
            path.setAttribute("d", "M " + from.x + " " + from.y + " C " + (from.x + 70) + " " + from.y + ", " + (to.x - 70) + " " + to.y + ", " + to.x + " " + to.y);
            path.setAttribute("fill", "none");
            path.setAttribute("stroke", "#4d7d58");
            path.setAttribute("stroke-width", "3");
            svg.appendChild(path);
        });
    }

    function positionPin(pin, type, port) {
        if (type === "COUNTER") {
            pin.style.left = port === "CLK" ? "-8px" : "auto";
            pin.style.right = port === "CLK" ? "auto" : "-8px";
            pin.style.top = port === "CLK" ? "17px" : (port === "Q2" ? "7px" : (port === "Q1" ? "25px" : "43px"));
            pin.style.transform = "translateY(-50%)";
        } else if (type === "CLK") {
            pin.style.right = "-8px";
            pin.style.left = "auto";
        } else {
            pin.style.left = "-8px";
        }
    }

    function handlePinClick(componentId, port) {
        const component = findComponent(componentId);
        if (!component) {
            return;
        }
        const isOutput = component.type === "CLK" && port === "output" ||
            component.type === "COUNTER" && ["Q2", "Q1", "Q0"].includes(port);
        if (!state.pendingConnection) {
            if (!isOutput) {
                setStatus("Start a wire from a clock or counter output terminal.", true);
                return;
            }
            state.pendingConnection = { from: componentId, fromPort: port };
            setStatus("Select a compatible destination input terminal.", false);
            return;
        }

        const source = findComponent(state.pendingConnection.from);
        const target = component;
        const sourcePort = state.pendingConnection.fromPort;
        state.pendingConnection = null;
        const validClock = source && source.type === "CLK" && sourcePort === "output" &&
            target.type === "COUNTER" && port === "CLK";
        const validOutput = source && source.type === "COUNTER" &&
            ["Q2", "Q1", "Q0"].includes(sourcePort) &&
            target.type === sourcePort && port === "input";
        if (!validClock && !validOutput) {
            setStatus("Invalid connection. Connect Clock to Counter CLK, or each counter output to its matching indicator.", true);
            return;
        }

        const occupied = state.connections.some(function (connection) {
            return connection.to === target.id && connection.toPort === port;
        });
        if (occupied) {
            setStatus("This input already has a driver. Remove the existing component or wire before reconnecting it.", true);
            return;
        }

        state.connections.push({
            from: source.id,
            fromPort: sourcePort,
            to: target.id,
            toPort: port
        });
        renderCanvas();
        setStatus("Connection successful.", false);
    }

    function validateCircuit() {
        const clocks = state.components.filter(function (component) { return component.type === "CLK"; });
        const counters = state.components.filter(function (component) { return component.type === "COUNTER"; });
        if (clocks.length !== 1 || counters.length !== 1) {
            return { valid: false, message: "Place exactly one clock input and one 3-bit synchronous counter." };
        }

        const indicators = {};
        ["Q2", "Q1", "Q0"].forEach(function (type) {
            indicators[type] = state.components.filter(function (component) { return component.type === type; });
            if (indicators[type].length !== 1) {
                indicators.missing = type;
            }
        });
        if (indicators.missing) {
            return { valid: false, message: "Place exactly one " + indicators.missing + " output indicator." };
        }

        const counter = counters[0];
        const requiredConnections = [
            { from: clocks[0].id, fromPort: "output", to: counter.id, toPort: "CLK" },
            { from: counter.id, fromPort: "Q2", to: indicators.Q2[0].id, toPort: "input" },
            { from: counter.id, fromPort: "Q1", to: indicators.Q1[0].id, toPort: "input" },
            { from: counter.id, fromPort: "Q0", to: indicators.Q0[0].id, toPort: "input" }
        ];
        const connectionsValid = requiredConnections.every(function (required) {
            return state.connections.some(function (connection) {
                return connection.from === required.from &&
                    connection.fromPort === required.fromPort &&
                    connection.to === required.to &&
                    connection.toPort === required.toPort;
            });
        });
        if (!connectionsValid || state.connections.length !== requiredConnections.length) {
            return { valid: false, message: "Connect Clock to CLK and each Q2, Q1, and Q0 output to its matching indicator." };
        }
        return { valid: true, message: "Circuit valid. All clock and output connections are correct." };
    }

    function updateReadout() {
        const bits = outputBits(state.pulseCount % 8);
        const pulseCount = document.getElementById("exp4PulseCount");
        const output = document.getElementById("exp4OutputValue");
        if (pulseCount) {
            pulseCount.textContent = state.initialized ? String(state.pulseCount) : "—";
        }
        if (output) {
            output.textContent = state.initialized ? bits.Q2 + " " + bits.Q1 + " " + bits.Q0 : "—";
        }
        renderTruthTable();
        renderProgress();
    }

    function renderTruthTable() {
        const body = document.getElementById("exp4TruthTableBody");
        if (!body) {
            return;
        }
        body.innerHTML = sequence.map(function (entry) {
            const result = state.results[entry.pulse];
            const bits = outputBits(entry.value);
            const expected = "" + bits.Q2 + bits.Q1 + bits.Q0;
            return "<tr><td>" + entry.pulse + "</td><td>" + expected + "</td><td>" +
                (result ? result.obtained : "—") + "</td><td>" +
                (result ? (result.correct ? "✓ Correct" : "✗ Incorrect") : "—") + "</td></tr>";
        }).join("");
    }

    function renderProgress() {
        const progress = document.getElementById("exp4ProgressStatus");
        if (progress) {
            progress.textContent = Object.keys(state.results).length + " of 9 states verified";
        }
    }

    function validateAndReport() {
        const validation = validateCircuit();
        if (!validation.valid) {
            const message = setting("connectionErrorDetection", true)
                ? validation.message
                : "Circuit is incomplete or invalid. Complete the required connections before simulation.";
            setStatus(message, true);
            return false;
        }
        setStatus(validation.message, false);
        return true;
    }

    function recordState(sequenceIndex) {
        if (!setting("truthTableVerification", true)) {
            return;
        }
        const actual = outputBits(state.pulseCount % 8);
        const obtained = "" + actual.Q2 + actual.Q1 + actual.Q0;
        const expectedValue = sequence[sequenceIndex].value;
        const expectedBits = outputBits(expectedValue);
        const expected = "" + expectedBits.Q2 + expectedBits.Q1 + expectedBits.Q0;
        state.results[sequenceIndex] = { obtained: obtained, correct: obtained === expected };
        renderTruthTable();
        renderProgress();
    }

    function initializeCounter() {
        if (!validateAndReport()) {
            return;
        }
        state.pulseCount = 0;
        state.initialized = true;
        state.results = {};
        recordState(0);
        renderCanvas();
        updateReadout();
        setStatus(
            setting("showOutputValues", true)
                ? "Counter initialized to 000. Apply a manual clock pulse to advance it."
                : "Counter initialized. Apply a manual clock pulse to advance it.",
            false
        );
    }

    function applyClockPulse() {
        if (!validateAndReport()) {
            return;
        }
        if (!state.initialized) {
            setStatus("Initialize the counter to 000 before applying clock pulses.", true);
            return;
        }

        state.pulseCount += 1;
        const sequenceIndex = state.pulseCount <= 8
            ? state.pulseCount
            : ((state.pulseCount - 1) % 8) + 1;
        recordState(sequenceIndex);
        renderCanvas();
        updateReadout();
        const bits = outputBits(state.pulseCount % 8);
        setStatus(
            setting("showOutputValues", true)
                ? "Rising clock edge applied. Counter state: " + bits.Q2 + bits.Q1 + bits.Q0 + "."
                : "Rising clock edge applied.",
            false
        );
    }

    function clearCircuit() {
        state.components = [];
        state.connections = [];
        state.pendingConnection = null;
        state.pulseCount = 0;
        state.initialized = false;
        state.results = {};
        renderCanvas();
        updateReadout();
        setStatus("Circuit cleared. Place and connect the required components.", false);
    }

    function startExperiment() {
        document.querySelector(".experiment-detail-panel").style.display = "none";
        document.getElementById("exp04Workspace").classList.remove("hidden");
        renderCanvas();
        updateReadout();
    }

    function initialize() {
        document.getElementById("startExp4Btn").addEventListener("click", startExperiment);
        document.getElementById("backToExp4Btn").addEventListener("click", function () {
            document.querySelector(".experiment-detail-panel").style.display = "block";
            document.getElementById("exp04Workspace").classList.add("hidden");
        });
        document.getElementById("exp4RunBtn").addEventListener("click", validateAndReport);
        document.getElementById("exp4PulseBtn").addEventListener("click", applyClockPulse);
        document.getElementById("exp4InitializeBtn").addEventListener("click", initializeCounter);
        document.getElementById("exp4ResetBtn").addEventListener("click", clearCircuit);
        document.querySelectorAll("[data-exp4-library]").forEach(function (button) {
            button.addEventListener("click", function () {
                createComponent(button.dataset.exp4Library);
            });
        });
        document.addEventListener("virtualdeldsettingschange", function () {
            updateReadout();
        });
        renderTruthTable();
        renderProgress();
    }

    document.addEventListener("DOMContentLoaded", initialize);
})();
